#include <bits/stdc++.h>

using namespace std;

typedef pair<int, int> PII;
typedef long long LL;

#define mp make_pair
#define pb push_back
#define fi first
#define se second

#define rep(i,l,r) for (int i=(l); i<=(r); i++)
#define repd(i,r,l) for (int i=(r); i>=(l); i--)
#define rept(i,c) for (__typeof((c).begin()) i=((c).begin()); i!=((c).end()); i++)

#define N 1000010
typedef long double DB;
const DB eps = 1e-8;
const DB eps2 = 2e-3;
int n;
int px[N], py[N];
int sn;


DB calc(int k, DB x) {
	if (px[k] == px[k + 1])
		return min(py[k], py[k + 1]);
	return  py[k] + (DB)(py[k + 1] - py[k]) * (x - px[k]) / (px[k + 1] - px[k]);
}

int main() {
	int t;
	cin >> t;
	while (t--) {
		cin >> n;
		for (int i = 0; i < n; i ++) {
			cin >> px[i] >> py[i];
		}
		DB S = 0;
		for (DB x1 = px[0]; x1 <= px[n - 1]; x1 += eps2)
		for (DB x2 = x1; x2 <= px[n - 1]; x2 += eps2) {
			DB y = 1e7;
			for (int i = 0; i < n - 1; i++) {
				if (px[i] < x1 && x1 < px[i + 1]) {
					y = min(y, calc(i, x1));
				}
				if (px[i] < x2 && x2 < px[i + 1]) {
					y = min(y, calc(i, x2));
				}
			}
			for (int i = 0; i < n; i++)
				if (x1 < px[i] && px[i] < x2)
					y = min(y, (DB)py[i]);
			S = max(S, (x2 - x1) * y);
		}
		printf ("%.2Lf\n", floor(S*100+eps)/100);
	}
	return 0;
}
