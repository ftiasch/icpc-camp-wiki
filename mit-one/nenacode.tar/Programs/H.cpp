#include <bits/stdc++.h>

using namespace std;

typedef pair<int, int> PII;
typedef long long LL;
typedef pair<double, double> PDD;

#define mp make_pair
#define pb push_back
#define fi first
#define se second

#define rep(i,l,r) for (int i=(l); i<=(r); i++)
#define repd(i,r,l) for (int i=(r); i>=(l); i--)
#define rept(i,c) for (__typeof((c).begin()) i=((c).begin()); i!=((c).end()); i++)

#define N 55
const double eps = 1e-8;


struct P {
	double x, y;
	P(){}
	P(double _x, double _y):x(_x), y(_y) {}
	
	P operator + (const P&a) const {return P(x+a.x, y+a.y);}
	P operator - (const P&a) const {return P(x-a.x, y-a.y);}
	P operator * (const double a) const {return P(x*a, y*a);}
	double crs(const P&a) const {return x*a.y-y*a.x;}
};
int n;
P p[N];
int L;
double q[N];

P ints(P p1, P pp1, P p2, P pp2) {
	P q1 = pp1 - p1;
	P q2 = pp2 - p2;
	double t = -((p1-p2).crs(q2))/(q1.crs(q2));
	return p1+q1*t;
}

int chk(P pp) {
	L = 0;
	for (int i = 0; i < n; i ++) {
		double x = p[i].x - pp.x;
		double y = p[i].y - pp.y;
		if (fabs(x) < eps && fabs(y) < eps) continue;
		double ang = atan2(y, x);
		if (ang < -M_PI+eps) ang += 2*M_PI;
		q[L++] = ang;
		//printf ("%.9lf\n", ang);
	}
	sort(q, q+L);
	int S = n;
	for (int i = 1; i < L; i ++)
		if (fabs(q[i]-q[i-1]) < eps) S --;
	//if (n == 9 && S == 2) {printf ("%.9lf %.9lf\n", pp.x, pp.y); exit(0);}
	return S;
}

int main() {
	int t;
	cin >> t;
	while (t--) {
		cin >> n;
		for (int i = 0; i < n; i ++) cin >> p[i].x >> p[i].y;
		int T = n;
		for (int i1 = 0; i1 < n; i1++)
			for (int j1 = i1+1; j1 < n; j1++)
				for (int i2 = i1; i2 < n; i2++)
					for (int j2 = i2+1; j2 < n; j2 ++) {
						if (fabs((p[i1]-p[j1]).crs(p[i2]-p[j2])) > eps) {
							P pp = ints(p[i1], p[j1], p[i2], p[j2]);
							T = min(T, chk(pp));
						}
					}
		for (int i = 0; i < n; i++)
			for (int j = 0; j < n; j++) {
				P pp = p[i]*2-p[j];
				T = min(T, chk(pp));
			}
		cout << T << endl;
	}
	return 0;
}
