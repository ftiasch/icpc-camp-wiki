#include <bits/stdc++.h>

using namespace std;

typedef pair<int, int> PII;
typedef long long LL;

#define mp make_pair
#define pb push_back
#define fi first
#define se second

#define rep(i,l,r) for (int i=(l); i<=(r); i++)
#define repd(i,r,l) for (int i=(r); i>=(l); i--)
#define rept(i,c) for (__typeof((c).begin()) i=((c).begin()); i!=((c).end()); i++)

int T, n, m;
int a[4100000], b[4100000];

int main() {
	//freopen("","r",stdin);
	scanf("%d", &T);
	while (T--) {
		scanf("%d%d", &m, &n);
		for (int i = 1; i <= m; i++)
			scanf("%d", &b[i]);
		for (int i = 1; i <= n; i++) {
			scanf("%d", &a[i]);
			
		}
		for (int i = 1; i <= m; i++)
			a[++n] = b[i];
		sort(a + 1, a + n + 1);
		sort(b +1, b + m +1);
		bool ok = true;
		for (int i = 1; i <= m; i++)
			if (a[n - m + i] <= b[i])
				ok = false;
		if (ok)
			printf("YES\n");
		else
			printf("NO\n");
	}	
	return 0;
}
