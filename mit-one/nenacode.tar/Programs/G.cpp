#include <bits/stdc++.h>

using namespace std;

typedef pair<int, int> PII;
typedef long long LL;

#define mp make_pair
#define pb push_back
#define fi first
#define se second

#define rep(i,l,r) for (int i=(l); i<=(r); i++)
#define repd(i,r,l) for (int i=(r); i>=(l); i--)
#define rept(i,c) for (__typeof((c).begin()) i=((c).begin()); i!=((c).end()); i++)

int T, n, m, a, b, c;
int dp[11000][2];
vector <int> ve[11000], ve1[11000];

bool ok(int x) {
	dp[1][0] = 0;
	dp[1][1] = n + 1;
	for (int i = 2; i <= n; i++) {
		dp[i][0] = dp[i][1] = n + 1;
		for (int j = 0; j < (int) ve[i].size(); j++) {
			int t = 1;
			if (ve1[i][j] <= x)
				t = -1;
			dp[i][0] = min(dp[i][0], dp[ve[i][j]][1] + t);
			dp[i][1] = min(dp[i][1], dp[ve[i][j]][0] + t);
		}
	}
	return dp[n][1] <= -1;
}

int main() {
	//freopen("","r",stdin);
	scanf("%d", &T);
	while (T--) {
		scanf("%d%d", &n, &m);
		for (int i = 1; i <= n; i++)
			ve[i].clear(), ve1[i].clear();
		while (m--) {
			scanf("%d%d%d", &a, &b, &c);
			ve[b].push_back(a);
			ve1[b].push_back(c);
		}
		int q = -10, h = 1000000010, mid;
		while (q < h - 1) {
			mid = (q + h) / 2;
			if (ok(mid))
				h = mid;
			else
				q = mid;
		}
		if (h > 1000000000)
			printf("NO\n");
		else
			printf("%d\n", h);
	}
	return 0;
}
