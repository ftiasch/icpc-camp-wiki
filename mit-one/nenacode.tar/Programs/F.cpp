#include <bits/stdc++.h>

using namespace std;

typedef pair<int, int> PII;
typedef long long LL;

#define mp make_pair
#define pb push_back
#define fi first
#define se second

#define rep(i,l,r) for (int i=(l); i<=(r); i++)
#define repd(i,r,l) for (int i=(r); i>=(l); i--)
#define rept(i,c) for (__typeof((c).begin()) i=((c).begin()); i!=((c).end()); i++)

#define N 1010
int a[N];
bool v[N];
int n;

int p[N];

int ff(int x) {
	if (x <= 1) return 0;
	if (x <= 2) return 1;
	return 2;
}

int main() {
	for (int i = 1; i <= 1000; i ++) {
		int j = 1, k = 0;
		while (j < i) {
			j+=j; k++;
		}
		p[i] = k;
	}
	int t;
	cin >> t;
	while (t--) {
		cin >> n;
		for (int i = 0; i < n; i++) v[i] = 0;
		for (int i = 0; i < n; i ++) {
			cin >> a[i];
			a[i] --;
		}
		int S = 0;
		for (int i = 0; i < n; i ++)
			if (!v[i]) {
				int j = i, k = 0;
				while (!v[j]) {
					v[j] = true;
					j = a[j];
					k++;
				}
				S = max(S, ff(k));
			}
		cout << S << endl;
	}
	return 0;
}
