#include <bits/stdc++.h>

using namespace std;

typedef pair<int, int> PII;
typedef long long LL;

#define mp make_pair
#define pb push_back
#define fi first
#define se second

#define rep(i,l,r) for (int i=(l); i<=(r); i++)
#define repd(i,r,l) for (int i=(r); i>=(l); i--)
#define rept(i,c) for (__typeof((c).begin()) i=((c).begin()); i!=((c).end()); i++)

#define N 1000010
typedef long double DB;
const DB eps = 1e-8;
struct P {
	DB x, y;
	P (){}
	P(DB _x, DB _y):x(_x),y(_y){}
	P operator + (const P&a) const {return P(x+a.x, y+a.y);}
	P operator - (const P&a) const {return P(x-a.x, y-a.y);}
	P operator * (DB a) const {return P(x*a, y*a);}
};
int n;
P a[N];
int px[N], py[N];
int sn;
pair<P, P> st[N];

DB ff(DB y0, DB y1, DB x0, DB x1, DB x2, DB x3) {
	// (a+bt)(c+dt)
	DB a = y0;
	DB b = y1-y0;
	DB c = x3-x0;
	DB d = (x2-x1)-(x3-x0);
	
	// A t^2 + Bt + C
	DB A = b*d;	
	DB B = b*c+a*d;
	DB C = a*c;
	
	DB S = 0;
	S = max(S, a*c);
	S = max(S, (a+b)*(c+d));
	
	// 2A t + B
	if (fabs(A) > 1e-12) {
		DB t0 = -B/(2*A);
		if (t0 >= 0.0 && t0 <= 1.0) {
			S = max(S, (a+t0*b)*(c+t0*d));
		}
	}
	return S;
}

DB gg(P p, P q, DB y0) {
	DB t = (y0-p.y)/(q.y-p.y);
	return (p + (q-p)*t).x;
}

int main() {
	int t;
	cin >> t;
	while (t--) {
		cin >> n;
		for (int i = 0; i < n; i ++) {
			cin >> px[i] >> py[i];
			a[i].x = px[i];
			a[i].y = py[i];
		}
		sn = 0;
		DB S = 0;
		for (int i = 1; i < n; i ++)
			if (py[i] > py[i-1]) {
				st[sn++] = mp(a[i-1], a[i]);
			} else
			if (py[i] < py[i-1]) {
				DB lasty = py[i-1];
				DB lastx = px[i-1];
				while (true) {
					if (sn == 0) break;
					if (st[sn-1].fi.y+eps < py[i]) {
						DB y0 = py[i];
						DB y1 = st[sn-1].se.y;
						DB x0 = gg(st[sn-1].fi, st[sn-1].se, y0);
						DB x1 = st[sn-1].se.x;
						DB x2 = lastx;
						DB x3 = px[i];
						S = max(S, ff(y0, y1, x0, x1, x2, x3));
						st[sn-1].se = P(x0, y0);
						break;
					}
					DB y0 = st[sn-1].fi.y;
					DB y1 = st[sn-1].se.y;
					DB x0 = st[sn-1].fi.x;
					DB x1 = st[sn-1].se.x;
					DB x2 = lastx;
					DB x3 = gg(a[i-1], a[i], y0);
					S = max(S, ff(y0, y1, x0, x1, x2, x3));
					lastx = x3;
					lasty = y0;
					sn --;
				}
			}
		// print S
		printf ("%.2Lf\n", floor(S*100+eps)/100);
	}
	return 0;
}
