#include <bits/stdc++.h>

using namespace std;

typedef pair<int, int> PII;
typedef long long LL;

#define mp make_pair
#define pb push_back
#define fi first
#define se second

#define rep(i,l,r) for (int i=(l); i<=(r); i++)
#define repd(i,r,l) for (int i=(r); i>=(l); i--)
#define rept(i,c) for (__typeof((c).begin()) i=((c).begin()); i!=((c).end()); i++)

LL get_lim(LL x, LL y)
{
	LL z=x-4*y-3;
	if (z<0) return 0;
	LL k=z/3;
	if (z%3) k++;
	return k;
}

LL calculate(LL x0, LL x1, LL x4, LL x5, LL k)
{
	if (k*3>x1 || k*3>x4) return 0;
	return min(x0/2, (x4-k*3)/4)+min(x5/2,(x1-k*3)/4)+k;
}

LL solve_part1(LL x0, LL x1, LL x4, LL x5)
{
	LL l1=get_lim(x4,x0/2);
	LL l2=get_lim(x1,x5/2);
	LL ans=0;
	rep(i,l1-100,l1+100)
	{
		if (i<0) continue;
		ans=max(ans,calculate(x0,x1,x4,x5,i));
	}
	rep(i,l2-100,l2+100)
	{
		if (i<0) continue;
		ans=max(ans,calculate(x0,x1,x4,x5,i));
	}
	LL l3=x4/3;
	rep(i,l3-100,l3+100)
	{
		if (i<0) continue;
		ans=max(ans,calculate(x0,x1,x4,x5,i));
	}
	LL l4=x1/3;
	rep(i,l4-100,l4+100)
	{
		if (i<0) continue;
		ans=max(ans,calculate(x0,x1,x4,x5,i));
	}
	rep(i,0,100)
	{
		if (i<0) continue;
		ans=max(ans,calculate(x0,x1,x4,x5,i));
	}
	return ans;
}

int choice[4][2]={
	{3,3},
	{4,2},
	{6,0},
	{0,6}
};

LL dp[4010][4010];

void precalc_part2()
{
	rep(i,0,4000)
		rep(j,0,4000)
			rep(k,0,3)
				if (i>=choice[k][0] && j>=choice[k][1])
					dp[i][j]=max(dp[i][j],dp[i-choice[k][0]][j-choice[k][1]]+1);
}

LL solve_part2(LL x3, LL x4)
{
	LL ans=0;
	if (x3>288) 
	{
		LL t=(x3-288)/6;
		if ((x3-288)%6) t++;
		x3-=6*t; ans+=t;
	}
	if (x4>288) 
	{
		LL t=(x4-288)/6;
		if ((x4-288)%6) t++;
		x4-=6*t; ans+=t;
	}
	return ans+dp[x3][x4];
}

void lemon()
{
	precalc_part2();
	rep(i,0,4000)
		rep(j,0,4000)
			if (dp[i][j]!=solve_part2(i,j))
			{
				printf("error! %d %d\n",i,j);
			}
			
}

int main() {
	//freopen("D.in","r",stdin);
	lemon();	
	return 0;
}
