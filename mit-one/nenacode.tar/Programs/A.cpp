#include <bits/stdc++.h>

using namespace std;

typedef pair<int, int> PII;
typedef long long LL;

#define mp make_pair
#define pb push_back
#define fi first
#define se second

#define rep(i,l,r) for (int i=(l); i<=(r); i++)
#define repd(i,r,l) for (int i=(r); i>=(l); i--)
#define rept(i,c) for (__typeof((c).begin()) i=((c).begin()); i!=((c).end()); i++)

int T, n;
int a[9][210][210], nx[500000], ny[500000], fa[9][210][210];
int dfn;
int tx[4] = {0, 0, 1, -1};
int ty[4] = {1, -1, 0, 0};
int ff[500000];
bool used[9];
int ans;
int to[9][9];
bool same[9][9];


void bfs(int a1[210][210], int fa1[210][210], int x, int y) {
	int q = 1, h = 1;
	nx[q = h = 1] = x;
	ny[1] = y;
	fa1[x][y] = dfn;
	while (q <= h) {
		int xx = nx[q], yy = ny[q];
		for (int i = 0; i < 4; i++) {
			int X = xx + tx[i], Y = yy + ty[i];
			if (!a1[X][Y] && !fa1[X][Y]) {
				h += 1;
				nx[h] = X;
				ny[h] = Y;
				fa1[X][Y] = dfn;
			}
		}
		q += 1;
	}
}

int gf(int x) {
	if (ff[x] != x)
		return ff[x] = gf(ff[x]);
	return ff[x];
}

void check() {
	if (a[to[0][0]][1][1])
		return ;
	if (a[to[2][2]][n][n])
		return ;
	int s = fa[to[0][0]][1][1], t = fa[to[2][2]][n][n];
	for (int i = 1; i <= dfn; i++)
		ff[i] = i;
	for (int i = 0; i < 2; i++)
	for (int j = 0; j < 3; j++)
	for (int p = 1; p <= n; p++)
	if (!a[to[i][j]][n][p] && !a[to[i + 1][j]][1][p])
		ff[gf(fa[to[i][j]][n][p])] = gf(fa[to[i + 1][j]][1][p]);
	
	for (int i = 0; i < 3; i++)
	for (int j = 0; j < 2; j++)
	for (int p = 1; p <= n; p++)
	if (!a[to[i][j]][p][n] && !a[to[i][j + 1]][p][1])
		ff[gf(fa[to[i][j]][p][n])] = gf(fa[to[i][j + 1]][p][1]);

	if (gf(s) == gf(t))
		ans += 1;
}

void dfs2(int x, int y) {
	if (x == 3)
		check();
	else if (y == 3) dfs2(x + 1, 0);
	else {
		for (int i = 0; i < 9; i++)
		if (!used[i]) {
			bool ok = true;
			for (int j = 0; j < i; j++)
			if (same[i][j] && !used[j])
				ok = false;
			if (!ok)
				continue;
			to[x][y] = i;
			used[i] = true;
			dfs2(x, y + 1);			
			used[i] = false;
		}
	}
}

int main() {
	scanf("%d", &T);
	while (T--) {
		scanf("%d", &n);
		memset(a, 1, sizeof a);
		for (int i = 0; i < 9; i++) {
			for (int j = 1; j <= n; j++)
			for (int p = 1; p <= n; p++)
			scanf("%d", &a[i][j][p]);
		}
		memset(same, false, sizeof same);
		for (int i = 0; i < 9; i++)
			for (int j = 0; j < i; j++) {
				bool ok = true;
				for (int p = 1; p <= n; p++)
				for (int q = 1; q <= n; q++)
				if (a[i][p][q] != a[j][p][q])
					ok = false;
				if (ok)
					same[i][j] = same[j][i] = true;
			}
		dfn = 0;
		memset(fa, 0, sizeof fa);
		for (int i = 0; i < 9; i++) {
			for(int j = 1; j <= n; j++)
			for (int p = 1; p <= n; p++)
			if (!fa[i][j][p] && !a[i][j][p]) {
				dfn += 1;
				bfs(a[i], fa[i], j, p);
			}
		}
		ans = 0;
		dfs2(0, 0);
		printf("%d\n", ans);
	}
	return 0;
}
