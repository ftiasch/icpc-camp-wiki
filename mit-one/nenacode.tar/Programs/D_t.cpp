#include <bits/stdc++.h>

using namespace std;

typedef pair<int, int> PII;
typedef long long LL;

#define mp make_pair
#define pb push_back
#define fi first
#define se second

#define rep(i,l,r) for (int i=(l); i<=(r); i++)
#define repd(i,r,l) for (int i=(r); i>=(l); i--)
#define rept(i,c) for (__typeof((c).begin()) i=((c).begin()); i!=((c).end()); i++)

int face[6][4]={
	{1,2,3,4},
	{5,6,7,8},
	{-4,12,-8,-9},
	{-3,11,-7,-12},
	{-2,-11,-6,10},
	{-1,-10,-5,9}
};

//SSSS 0
//SSSN 1
//SSNN 2
//SNSN 3
//SNNN 4
//NNNN 5

int type[16]={
	0,		//SSSS
	1,		//SSSN
	1,		//SSNS
	2,		//SSNN
	1,		//SNSS
	3,		//SNSN
	2,		//SNNS
	4,		//SNNN
	1,		//NSSS
	2,		//NSSN
	3,		//NSNS
	4,		//NSNN
	2,		//NNSS
	4,		//NNSN
	4,		//NNNS
	5		//NNNN
};

int can1[10];
vector<int> can2[10][10];

void lemon()
{
	rep(state,0,(1<<12)-1)
	{
		int cnt[6]; memset(cnt,0,sizeof cnt);
		rep(i,0,5)
		{
			int t=0;
			rep(j,0,3)
			{
				int f1=0, f2=0;
				if (state&(1<<(abs(face[i][j])-1))) f1=1;
				if (face[i][j]>0) f2=1;
				if (f1^f2) t|=1<<j;
			}
			t=type[t];
			cnt[t]++;
		}
		int nnz=0;
		rep(i,0,5) if (cnt[i]) nnz++;
		if (nnz>2) continue;
		int all=0, z[2];
		rep(i,0,5) if (cnt[i]) z[all]=i, all++;
		if (nnz==1)
			can1[z[0]]=1;
		else
			can2[z[0]][z[1]].push_back(cnt[z[0]]);
	}
	printf("1 type:\n");
	rep(i,0,5) printf("%d ",can1[i]);
	printf("\n");
	printf("2 types\n");
	rep(i,0,5)
		rep(j,i+1,5)
			rept(it,can2[i][j])
			{
				printf("Type %d %d, cnt %d\n",i,j,*it);
			}
}

int main() {
	//freopen("","r",stdin);
	lemon();	
	return 0;
}
