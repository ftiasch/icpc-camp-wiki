#include <bits/stdc++.h>

using namespace std;

typedef pair<int, int> PII;
typedef long long LL;

#define mp make_pair
#define pb push_back
#define fi first
#define se second

#define rep(i,l,r) for (int i=(l); i<=(r); i++)
#define repd(i,r,l) for (int i=(r); i>=(l); i--)
#define rept(i,c) for (__typeof((c).begin()) i=((c).begin()); i!=((c).end()); i++)

int T, n, a[100], b[100];
int dp[31][310000];

int main() {
	//freopen("","r",stdin);
	scanf("%d", &T);
	while (T--) {
		scanf("%d", &n);
		for (int i = 1; i <= n; i++)
			scanf("%d%d", &a[i], &b[i]);
		memset(dp, 0, sizeof dp);
		dp[0][0] = 1;
		for (int i = 1; i <= n; i++) {
			for (int j = 300000; j >= 0; j--)
				if (dp[i - 1][j]) {
					dp[i][j + a[i]] += dp[i - 1][j];
					dp[i][j + b[i]] += dp[i - 1][j];
				}
		}
		int x = 1 << (n - 1);
		for (int i = 0; i <= 300000; i++) {
			x -= dp[n][i];
			if (x <= 0) {
				printf("%d\n", i);
				break;
			}
		}
	}
	return 0;
}
