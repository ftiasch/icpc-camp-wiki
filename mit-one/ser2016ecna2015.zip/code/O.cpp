#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
typedef pair<int, int> PII;

#define fi first
#define se second
#define pb push_back
#define mp make_pair
#define pct __builtin_popcount

#define rep(i,l,r) for (int i=(l); i<=(r); i++)
#define repd(i,r,l) for (int i=(r); i>=(l); i--)
#define rept(i,c) for (__typeof((c).begin()) i=((c).begin()); i!=((c).end()); i++)

#define maxn 110

int delx[4]={0,0,1,-1};
int dely[4]={-1,1,0,0};

int ans[maxn][maxn];
char g[maxn][maxn];

void lemon()
{
	int n,m; scanf("%d%d",&n,&m);
	rep(i,1,n) scanf("%s",g[i]+1);
	rep(i,1,n) rep(j,1,m) ans[i][j]=-1;
	rep(i,1,n)
		rep(j,1,m)
			if (g[i][j]=='.')
				ans[i][j]=0;
	
	rep(lb,1,1000)
		rep(i,0,n+1)
			rep(j,0,m+1)
				if (ans[i][j]==lb-1)
					rep(k,0,3)
					{
						int ni=i+delx[k], nj=j+dely[k];
						if (1<=ni && ni<=n && 1<=nj && nj<=m && ans[ni][nj]==-1) ans[ni][nj]=lb;
					}
	
	int rn=0;
	rep(i,1,n) rep(j,1,m) rn=max(rn,ans[i][j]);
	
	if (rn<10) rn=2; else rn=3;
	
	rep(i,1,n)
	{
		rep(j,1,m)
			if (ans[i][j]==0)
				rep(k,1,rn) printf(".");
			else
			{
				int len;
				if (ans[i][j]<10) len=1; else if (ans[i][j]<100) len=2; else len=3;
				rep(k,1,rn-len) printf(".");
				printf("%d",ans[i][j]);
			}
		printf("\n");
	}
			
}

int main() {
	//freopen("O.in","r",stdin);
	lemon();
	return 0;
}
