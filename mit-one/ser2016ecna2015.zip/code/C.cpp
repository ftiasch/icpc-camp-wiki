#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
typedef pair<int, int> PII;
typedef pair<PII, int> PI3;

#define fi first
#define se second
#define pb push_back
#define mp make_pair
#define pct __builtin_popcount

#define rep(i,l,r) for (int i=(l); i<=(r); i++)
#define repd(i,r,l) for (int i=(r); i>=(l); i--)
#define rept(i,c) for (__typeof((c).begin()) i=((c).begin()); i!=((c).end()); i++)

#define N 55

int n, m;
string a[N];
int p;
string s;

int xs, ys;
int xe, ye;

int f[N][N][N];
bool v[N][N][N];

const int dx[4] = {-1,0,1,0};
const int dy[4] = {0,1,0,-1};

map<char, int> dr;

bool valid(int x, int y) {
	if (x >= 0 && x < n && y >= 0 && y < m) {
		if (a[x][y] != '#') return true;
	}
	return false;
}

queue<PI3> q;

void add(int x1, int y1, int z1, int u) {
	if (f[x1][y1][z1] == -1 || f[x1][y1][z1] > u) {
		f[x1][y1][z1] = u;
		if (!v[x1][y1][z1]) {
			v[x1][y1][z1] = 1;
			q.push(mp(mp(x1,y1),z1));
		}
	}
}

int main() {
	dr['L'] = 3;
	dr['R'] = 1;
	dr['U'] = 0;
	dr['D'] = 2;
	cin >> n >> m;
	for (int i = 0; i < n; i ++)
		cin >> a[i];
	cin >> s;
	p = (int) s.length();
	
	for (int i = 0; i < n; i ++)
		for (int j = 0; j < m; j++) {
			if (a[i][j] == 'R') {
				xs = i;
				ys = j;
			}
			if (a[i][j] == 'E') {
				xe = i;
				ye = j;
			}
		}

	memset(f, -1, sizeof f);
	f[xs][ys][0] = 0;
	
	q.push(mp(mp(xs, ys), 0));
	v[xs][ys][0] = 1;
	while (!q.empty()) {
		PI3 _x = q.front();
		q.pop();
		int xx = _x.fi.fi;
		int yy = _x.fi.se;
		int zz = _x.se;
		v[xx][yy][zz] = 0;
		
		// delete
		if (zz != p) {
			int x1 = xx;
			int y1 = yy;
			int z1 = zz + 1;
			add(x1, y1, z1, f[xx][yy][zz] + 1);
		}
		
		// insert
		for (int d = 0; d < 4; d++) {
			int x1 = xx + dx[d];
			int y1 = yy + dy[d];
			int z1 = zz;
			if (!valid(x1, y1)) {
				x1 = xx;
				y1 = yy;
			}
			add(x1, y1, z1, f[xx][yy][zz] + 1);
		}
		
		// use
		if (zz != p) {
			int d = dr[s[zz]];
			int x1 = xx + dx[d];
			int y1 = yy + dy[d];
			int z1 = zz + 1;
			if (!valid(x1, y1)) {
				x1 = xx;
				y1 = yy;
			}
			add(x1, y1, z1, f[xx][yy][zz]);
		}
	}
	int S = f[xe][ye][p];
	for (int i = 0; i <= p; i ++)
		S = min(S, f[xe][ye][i]);
	cout << S << endl;
	return 0;
}
