#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
typedef pair<int, int> PII;

#define fi first
#define se second
#define pb push_back
#define mp make_pair
#define pct __builtin_popcount

#define rep(i,l,r) for (int i=(l); i<=(r); i++)
#define repd(i,r,l) for (int i=(r); i>=(l); i--)
#define rept(i,c) for (__typeof((c).begin()) i=((c).begin()); i!=((c).end()); i++)

void lemon()
{
}

string shift(string a) {
	int n = (int) a.length();
	string b = string(1, a[n-1]);
	b += a.substr(0, n-1);
	return b;
}

int main() {
	//freopen("","r",stdin);
	lemon();
	string s;
	cin >> s;
	int n = (int) s.length();
	for (int u = 1; u <= n; u++) if (n%u == 0) {
		string la = s.substr(0, u);
		bool F = true;
		for (int i = u; i < n; i += u) {
			string t = s.substr(i, u);
			if (t != shift(la)) {
				F = false;
				break;
			}
			la = t;
		}
		if (F) {
			cout << u << endl;
			return 0;
		}
	}
	return 0;
}
