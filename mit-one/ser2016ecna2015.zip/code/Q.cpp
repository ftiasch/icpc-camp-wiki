#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
typedef pair<int, int> PII;

#define fi first
#define se second
#define pb push_back
#define mp make_pair
#define pct __builtin_popcount

#define rep(i,l,r) for (int i=(l); i<=(r); i++)
#define repd(i,r,l) for (int i=(r); i>=(l); i--)
#define rept(i,c) for (__typeof((c).begin()) i=((c).begin()); i!=((c).end()); i++)

#define N 3000
#define M 5000000

#define INF 1000000000

int s, t;
int n1[N];
int len, Next[M], till[N], go[M], f[M];
bool cc[N];
int D[N];

void add(int a, int b, int c) {
	Next[++len] = till[a];
	till[a] = len;
	go[len] = b;
	f[len] = c;
}

void Ad(int a, int b, int c) {
	add(a, b, c);
	add(b, a, 0);
}

bool bfs() {
	int q, h, i;
	memset(D, 0, sizeof D);
	memset(cc, 1, sizeof cc);
	for (D[n1[q = h = 1] = s] = 1; q <= h; q++)
		for (i = till[n1[q]]; i; i = Next[i])
			if (f[i] && !D[go[i]])
				D[n1[++h] = go[i]] = D[n1[q]] + 1;
	return D[t]; 
}

int dfs(int k, int mi) {
	if (k == t)
		return mi;
	int i, tmp, sum = 0;
	for (i = till[k]; i && mi; i = Next[i])
		if (f[i] && D[go[i]] == D[k] + 1 && cc[go[i]]) {
			tmp = dfs(go[i], min(mi, f[i]));
			sum += tmp;
			mi -= tmp;
			f[i] -= tmp;
			f[i ^ 1] += tmp;
		}
	if (!sum)
		cc[k] = false;
	return sum;
}


int maxFlow() {
	int sum = 0;
	while (bfs())
		sum += dfs(s, INF);
	return sum;
}

int main() {
	freopen("Q.in","r",stdin);
	len = 1;
	int ss,raw,fac,tra; scanf("%d%d%d%d",&ss,&raw,&fac,&tra);
	int n=ss+tra*2+2;
	s=n-1; t=n;
	map<string,int> sname;
	rep(i,1,raw)
	{
		string sn; cin>>sn;
		sname[sn]=i;
	}
	rep(i,1,fac)
	{
		string sn; cin>>sn;
		sname[sn]=raw+i;
	}
	int all=raw+fac;
	rep(i,1,raw) Ad(s,i,1);
	rep(i,1,fac) Ad(raw+i,t,1);
	rep(i,1,tra) Ad(ss+i,ss+tra+i,1);
	rep(i,1,tra)
	{
		int k; scanf("%d",&k);
		rep(j,1,k)
		{
			string sn; cin>>sn;
			if (!sname.count(sn)) { all++; sname[sn]=all; }
			int v=sname[sn];
			Ad(v,ss+i,1);
			Ad(ss+tra+i,v,1);
		}
	}
	cout<<maxFlow()<<endl;
	return 0;
}
