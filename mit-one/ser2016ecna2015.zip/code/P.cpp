#include <bits/stdc++.h>
using namespace std;

typedef long long LL;
typedef pair<int, int> PII;

#define fi first
#define se second
#define pb push_back
#define mp make_pair
#define pct __builtin_popcount

#define rep(i,l,r) for (int i=(l); i<=(r); i++)
#define repd(i,r,l) for (int i=(r); i>=(l); i--)
#define rept(i,c) for (__typeof((c).begin()) i=((c).begin()); i!=((c).end()); i++)

#define maxn 110

LL dp[20][maxn];
vector<int> e[maxn];

void lemon()
{
	int n,m,s,t; scanf("%d%d%d%d",&n,&m,&s,&t);
	rep(i,1,m)
	{
		int x,y; scanf("%d%d",&x,&y);
		x++; y++;
		e[x].push_back(y); e[y].push_back(x);
	}
	s++;
	dp[0][s]=1;
	rep(i,0,t-1)
		rep(j,1,n)
			rept(it,e[j])
				dp[i+1][*it]+=dp[i][j];
		
	LL sum=0;
	rep(i,1,n) sum+=dp[t][i];
	cout<<sum<<endl;
}

int main() {
	freopen("P.in","r",stdin);
	lemon();
	return 0;
}
