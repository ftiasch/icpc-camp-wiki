#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
typedef pair<int, int> PII;

#define fi first
#define se second
#define pb push_back
#define mp make_pair
#define pct __builtin_popcount

#define rep(i,l,r) for (int i=(l); i<=(r); i++)
#define repd(i,r,l) for (int i=(r); i>=(l); i--)
#define rept(i,c) for (__typeof((c).begin()) i=((c).begin()); i!=((c).end()); i++)

#define N 2010
int n, r, p;
int px[N], py[N];

// 2*i -
// 2*i+1 |

vector<int> E[N];
vector<int> IE[N];

bool chk(int x, int y) {
	int l1 = x-r;
	int r1 = x+r;
	int l2 = y-r;
	int r2 = y+r;
	if (r1 < l2) return true;
	if (r2 < l1) return true;
	return false;
}

void addE(int x, int y) {
	E[x].pb(y^1);
	IE[y^1].pb(x);
	E[y].pb(x^1);
	IE[x^1].pb(y);
}

int mk, st[N], sn, c[N], v[N];

void ff1(int x) {
	v[x] = 1;
	for (int i = 0; i < (int) E[x].size(); i++)
		if (!v[E[x][i]]) ff1(E[x][i]);
	st[sn++] = x;
}

void ff2(int x) {
	v[x] = 0;
	for (int i = 0; i < (int) IE[x].size(); i++) 
		if (v[IE[x][i]]) ff2(IE[x][i]);
	c[x] = mk;
}

int main() {
	cin >> n >> r >> p;
	for (int i = 0; i < p; i ++) {
		cin >> px[i] >> py[i];
		px[i] --;
		py[i] --;
	}
	for (int i = 0; i < p; i ++)
		for (int j = i+1; j < p; j ++) {
			if (px[i] == px[j]) {
				if (!chk(py[i], py[j])) addE(i*2,j*2);
			}
			if (py[i] == py[j]) {
				if (!chk(px[i], px[j])) addE(i*2+1, j*2+1);
			}
		}
	int nn = p*2;
	sn = 0;
	for (int i = 0; i < nn; i++)
		if (!v[i]) ff1(i);
	mk = 0;
	for (int i = nn-1; i >= 0; i--)
		if (v[st[i]]) {
			ff2(st[i]);
			mk ++;
		}
	bool F = true;
	for (int i = 0; i < nn; i++)
		if (c[i] == c[i^1]) F = false;
	if (F) puts ("1"); else puts ("0");
	return 0;
}
