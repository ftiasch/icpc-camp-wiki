#include <bits/stdc++.h>
using namespace std;

typedef long long LL;
typedef pair<int, int> PII;

#define fi first
#define se second
#define pb push_back
#define mp make_pair
#define pct __builtin_popcount

#define rep(i,l,r) for (int i=(l); i<=(r); i++)
#define repd(i,r,l) for (int i=(r); i>=(l); i--)
#define rept(i,c) for (__typeof((c).begin()) i=((c).begin()); i!=((c).end()); i++)

int cannot[30][8];
LL dp[30][8];

void lemon()
{
	int n,m; scanf("%d%d",&n,&m);
	rep(i,1,m)
	{
		double x,y; scanf("%lf%lf",&x,&y);
		int xi=floor(x), yi=floor(y);
		//cout<<xi<<" "<<yi<<endl;
		cannot[xi][yi]=1;
	}
	dp[0][0]=1;
	rep(i,0,n-1)
		rep(j,0,7)
		{
			//0 = no put
			//1 = single
			//2 = column 1x2
			//3 = row 1x2
			int p[3];
			for (p[0]=0; p[0]<=3; p[0]++)
				for (p[1]=0; p[1]<=3; p[1]++)
					for (p[2]=0; p[2]<=2; p[2]++)
					{
						int cnt[2][3]; memset(cnt,0,sizeof cnt);
						rep(k,0,1)
							rep(l,0,2)
								if (cannot[i+k][l])
									cnt[k][l]++;
						
						rep(k,0,2)
							if (j&(1<<k))
								cnt[0][k]++;
						
						rep(k,0,2)
						{
							if (p[k]==1)
							{
								cnt[0][k]++;
							}
							if (p[k]==3)
							{
								cnt[0][k]++;
								cnt[0][k+1]++;
							}
							if (p[k]==2)
							{
								cnt[0][k]++;
								cnt[1][k]++;
							}
						}
						
						int flag=1;
						rep(k,0,1)
							rep(l,0,2)
								if (cnt[k][l]>1)
									flag=0;
						
						rep(k,0,2)
							if (cnt[0][k]<1)
								flag=0;
						
						if (!flag) continue;
						
						rep(k,0,2)
							if (cannot[i+1][k])
								cnt[1][k]--;
								
						int ns=0;
						rep(k,0,2) ns|=cnt[1][k]<<k;
						
						dp[i+1][ns]+=dp[i][j];
					}
		}
	
	cout<<dp[n][0]<<endl;	
}

int main() {
	freopen("R.in","r",stdin);
	lemon();
	return 0;
}
