#include <bits/stdc++.h>
using namespace std;

typedef long long LL;
typedef pair<int, int> PII;

#define fi first
#define se second
#define pb push_back
#define mp make_pair
#define pct __builtin_popcount

#define rep(i,l,r) for (int i=(l); i<=(r); i++)
#define repd(i,r,l) for (int i=(r); i>=(l); i--)
#define rept(i,c) for (__typeof((c).begin()) i=((c).begin()); i!=((c).end()); i++)

LL ans;
int n,m;
char op;

int rused[11][11], cused[11][11];
int dx[11], dy[11];

void dfs(int c, int goal)
{
	if (c==m)
	{
		if (1<=goal && goal<=n && !rused[dx[c]][goal] && !cused[dy[c]][goal])
			ans++;
		return;
	}
	
	rep(i,1,n)
		if (!rused[dx[c]][i] && !cused[dy[c]][i])
		{
			int flag=0;
			if (op=='+' && goal>i) flag=1;
			if (op=='*' && goal%i==0) flag=1;
			if (flag)
			{
				rused[dx[c]][i]=1; cused[dy[c]][i]=1;
				if (op=='+') dfs(c+1,goal-i);
				if (op=='*') dfs(c+1,goal/i);
				rused[dx[c]][i]=0; cused[dy[c]][i]=0;
			}
		}
}

void lemon()
{
	int t; scanf("%d%d%d",&n,&m,&t);
	while (1)
	{
		scanf("%c",&op);
		if (op=='+' || op=='-' || op=='*' || op=='/') break;
	}
	rep(i,1,m) scanf("%d%d",&dx[i],&dy[i]);
	if (op=='-')
	{
		LL ans=0;
		rep(i,1,n)
			rep(j,i+1,n)
			{
				if (j-i==t) ans++;
			}
		cout<<ans*2<<endl;
		return;
	}
	if (op=='/')
	{
		LL ans=0;
		rep(i,1,n)
			rep(j,i+1,n)
			{
				if (j==t*i) ans++;
			}
		cout<<ans*2<<endl;
		return;
	}
	rep(i,1,n) 
		rep(j,1,n)
		{
			rused[i][j]=0; cused[i][j]=0;
		}
	
	ans=0;
	dfs(1,t);
	cout<<ans<<endl;
}

int main() {
	freopen("N.in","r",stdin);
	lemon();
	return 0;
}
