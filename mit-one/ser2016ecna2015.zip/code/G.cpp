#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
typedef pair<int, int> PII;

#define fi first
#define se second
#define pb push_back
#define mp make_pair
#define pct __builtin_popcount

#define rep(i,l,r) for (int i=(l); i<=(r); i++)
#define repd(i,r,l) for (int i=(r); i>=(l); i--)
#define rept(i,c) for (__typeof((c).begin()) i=((c).begin()); i!=((c).end()); i++)

#define N 55
int n, m;
string a[N];
bool v[N][N];

const int dx[4] = {-1,0,1,0};
const int dy[4] = {0,-1,0,1};

void ff0(int x0, int y0) {
	queue<PII> q;
	q.push(mp(x0, y0));
	while (!q.empty()) {
		PII _x = q.front();
		q.pop();
		int x = _x.fi, y = _x.se;
		for (int d = 0; d < 4; d++) {
			int x1 = x+dx[d];
			int y1 = y+dy[d];
			if (x1 >= 0 && x1 < n && y1 >= 0 && y1 < m) {
				if ((a[x1][y1] == 'L' || a[x1][y1] == 'C') && !v[x1][y1]) {
					a[x1][y1] = 'L';
					v[x1][y1] = 1;
					q.push(mp(x1,y1));
				}
			}
		}
	}
}

int main() {
	cin >> n >> m;
	for (int i = 0; i < n; i ++)
		cin >> a[i];
	memset(v, 0, sizeof v);
	int S = 0;
	for (int i = 0; i < n; i ++)
		for (int j = 0; j < m; j ++)
			if (a[i][j] == 'L' && !v[i][j]) {ff0(i,j); S++;}
	cout << S << endl;
	return 0;
}
