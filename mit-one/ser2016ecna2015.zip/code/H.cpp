#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
typedef pair<int, int> PII;

#define fi first
#define se second
#define pb push_back
#define mp make_pair
#define pct __builtin_popcount

#define rep(i,l,r) for (int i=(l); i<=(r); i++)
#define repd(i,r,l) for (int i=(r); i>=(l); i--)
#define rept(i,c) for (__typeof((c).begin()) i=((c).begin()); i!=((c).end()); i++)

struct aa {
	long long a, b;
} q[210000];

int len, root;
int son[13000000][2];
long long ma[13000000];

long long n;
int k;

bool cmp(aa a, aa b) {
	return a.a < b.a;
}

long long query(int k, long long q, long long h, long long l, long long r) {
	if (!k)
		return 0;
	if (l <= q && h <= r)
		return ma[k];
	if (r <= (q + h) / 2)
		return query(son[k][0], q, (q + h) / 2, l, r);
	if ((q + h) / 2 < l)
		return query(son[k][1], (q + h) / 2 + 1, h, l, r);
	return max(query(son[k][0], q, (q + h) / 2, l, r), query(son[k][1], (q + h) / 2 + 1, h, l, r));
}

void modify(int &k, long long q, long long h, long long x, long long y) {
	if (!k)
		k = ++len;
	ma[k] = max(ma[k], y);
	if (q < h) {
		if (x <= (q + h) / 2)
			modify(son[k][0], q, (q + h) / 2, x, y);
		else
			modify(son[k][1], (q + h) / 2 + 1, h, x, y);
	}
}

int main() {
	//freopen("","r",stdin);
	cin >> n >> k;
	for (int i = 1; i <= k; i++) {
		cin >> q[i].a >> q[i].b;
	}
	sort(q + 1, q + k + 1, cmp);
	
	for (int i = 1; i <= k; i++) {
		long long x = 0;
		if (q[i].a != 1) {
			x = query(root, 1, n, 1, q[i].a - 1);
		}
		modify(root, 1, n, q[i].b, x + q[i].b - q[i].a + 1);
	}
	cout << n - query(root, 1, n, 1, n) << endl;
	return 0;
}
