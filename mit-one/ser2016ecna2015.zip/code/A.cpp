#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
typedef pair<int, int> PII;

#define fi first
#define se second
#define pb push_back
#define mp make_pair
#define pct __builtin_popcount

#define rep(i,l,r) for (int i=(l); i<=(r); i++)
#define repd(i,r,l) for (int i=(r); i>=(l); i--)
#define rept(i,c) for (__typeof((c).begin()) i=((c).begin()); i!=((c).end()); i++)

void lemon()
{
}

int ans;
char S[11000];
int dp[11000];

int main() {
	//freopen("","r",stdin);
	scanf("%s", S + 1);
	int n = strlen(S + 1);
	dp[0] = 0;
	for (int i = 1; i <= n; i++) {
		for (int j = 0; j < i; j++)
			if (S[j] < S[i])
				dp[i] = max(dp[i], dp[j] + 1);
		ans = max(ans, dp[i]);
	}
	printf("%d\n", 26 - ans);
	return 0;
}
