#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
typedef pair<int, int> PII;

#define fi first
#define se second
#define pb push_back
#define mp make_pair
#define pct __builtin_popcount

#define rep(i,l,r) for (int i=(l); i<=(r); i++)
#define repd(i,r,l) for (int i=(r); i>=(l); i--)
#define rept(i,c) for (__typeof((c).begin()) i=((c).begin()); i!=((c).end()); i++)

void lemon()
{
}

int n, a[1100000], b[1100000], c[1100000];

int get(int b[1100000], int x) {
	int ans = 0;
	for (; x; x -= x & -x)
		ans = max(ans, b[x]);
	return ans;
}

void modify(int b[1100000], int x, int y) {
	for (; x <= 1000000; x += x & -x)
		b[x] = max(b[x], y);
}

int main() {
	scanf("%d", &n);
	for (int i = 1; i <= n; i++)
		scanf("%d", &a[i]);
	for (int i = 1; i <= n; i++) {
		int x = max(1, get(b, a[i] - 1) + 1);
		int y = max(1, get(c, 1000000 - a[i]) + 1);
		modify(c, 1000000 - a[i] + 1, x);
		modify(b, a[i], y);
	}
	printf("%d\n", max(get(b, 1000000), get(c, 1000000)));
	return 0;
}
