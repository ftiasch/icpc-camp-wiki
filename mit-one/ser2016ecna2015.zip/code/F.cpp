#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
typedef pair<int, int> PII;

#define fi first
#define se second
#define pb push_back
#define mp make_pair
#define pct __builtin_popcount

#define rep(i,l,r) for (int i=(l); i<=(r); i++)
#define repd(i,r,l) for (int i=(r); i>=(l); i--)
#define rept(i,c) for (__typeof((c).begin()) i=((c).begin()); i!=((c).end()); i++)

#define N 1010

struct P {
	int x, y;
	P(){}
	P(int _x, int _y):x(_x),y(_y){}
	void get() {cin >> x >> y;}
	double tan() const {return atan2(y, x);}
	double crs(const P&a) const {return x*a.y - y*a.x;}
};

int n;
P a[N];
int h[N];
double v[N];

bool cmp(P x, P y) {
	return x.tan() < y.tan();
}

int main() {
	cin >> n;
	for (int i = 0; i < n-1; i ++)
		a[i].get();
	for (int i = 0; i < n; i ++)
		cin >> h[i];
	sort(a, a+n-1, cmp);
	
	for (int i = 0; i < n-1; i ++) {
		int ne = (i+1)%(n-1);
		double u = a[i].crs(a[ne]);
		v[i] += u;
		v[ne] += u;
		v[n-1] += u;
	}
	
	sort(h, h+n);
	sort(v, v+n);
	double S = 0;
	for (int i = 0; i < n; i ++)
		S += v[i] * h[i];
	printf ("%.2lf\n", S/6);
	return 0;
}
