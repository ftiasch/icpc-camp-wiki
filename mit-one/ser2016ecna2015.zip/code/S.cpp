#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
typedef pair<int, int> PII;

#define fi first
#define se second
#define pb push_back
#define mp make_pair
#define pct __builtin_popcount

#define rep(i,l,r) for (int i=(l); i<=(r); i++)
#define repd(i,r,l) for (int i=(r); i>=(l); i--)
#define rept(i,c) for (__typeof((c).begin()) i=((c).begin()); i!=((c).end()); i++)

const string invalid = "impossible";
const double eps = 1e-8;

struct P {
	double x, y;
	P(){}
	P(double _x, double _y):x(_x), y(_y){}
	P operator + (const P&a) const {return P(x+a.x, y+a.y);}
	P operator - (const P&a) const {return P(x-a.x, y-a.y);}
	P operator * (double a) const {return P(x*a, y*a);}
	P operator / (double a) const {return P(x/a, y/a);}
	double abs () const {return sqrt(x*x+y*y);}
	P reg() const {return (*this)/abs();}
	double tan () const {return atan2(y, x);}
	double dot (const P&a) const {return x*a.x + y*a.y;}
	double crs (const P&a) const {return x*a.y - y*a.x;}
	P rot () const {return P(y,-x);}
};

int r;
P col_pt(P start, P end) {
	return start + (start - end).reg()*r*2;
}

void end() {
	cout << invalid << endl;
	exit(0);
}

// refl l1 wrt l2, only return slope
P refl(P l1, P l2) {
	l2 = l2.reg();
	return l1 - (l1-l2*l1.dot(l2))*2.0;
}

P ints (P p, P l1, double h) {
	if (fabs(l1.y) < eps) end();
	if (p.y+eps < h) end();
	return p - l1*(p.y-h)/l1.y;
}

bool chk(P p, P l1, P q) {
	double d = fabs((q-p).crs(l1))/l1.abs();
	if (d - eps > 2*r) return true;
	P q1 = q - l1.reg().rot() * d;
	P q2 = q + l1.reg().rot() * d;
	cout << fabs((q1-p).abs() + (q1-(p+l1)).abs() - l1.abs()) << endl;
	if ((q1-p).crs(l1) < eps) {
		if ((q1-p).abs() > eps && (q1-(p+l1)).abs() > eps && fabs((q1-p).abs() + (q1-(p+l1)).abs() - l1.abs()) < eps) return false;
	}
	if ((q2-p).crs(l1) < eps) {
		if ((q2-p).abs() > eps && (q2-(p+l1)).abs() > eps && fabs((q2-p).abs() + (q2-(p+l1)).abs() - l1.abs()) < eps) return false;
	}
	return true;
}

int main() {
	int w, l;
	int x1, y1, x2, y2, x3, y3, h;
	cin >> w >> l >> r >> x1 >> y1 >> x2 >> y2 >> x3 >> y3 >> h;
	P p1(x1, y1);
	P p2(x2, y2);
	P p3(x3, y3);
	
	P top_right(w, l);
	P top_left(0, l);
	
	P p1_to_p3 = col_pt(p3, top_right);
	P cue_to_p1 = col_pt(p1, p1_to_p3);
	P cue_to_p2 = col_pt(p2, top_left);
	
	P cue_line = refl(cue_to_p1 - cue_to_p2, p1 - p1_to_p3);
	if (cue_line.y < 0) end();
	//printf ("%.9lf %.9lf\n", cue_to_p1.x, cue_to_p1.y);
	//printf ("%.9lf %.9lf %.9lf\n", cue_line.x, cue_line.y, (double)h);
	P cue = ints(cue_to_p1, cue_line, h);
	//printf ("%.9lf %.9lf\n", cue.x, cue.y);
	//printf ("%.9lf\n", (cue_to_p1 - cue).crs(cue_line));
	assert(fabs(cue.y-h) < eps);
	if (cue.x-r + eps < 0 || cue.x+r - eps > w) end();
	if ((cue-p1).abs() + eps < r*2) end();
	if ((cue-p2).abs() + eps < r*2) end();
	if ((cue-p3).abs() + eps < r*2) end();
	
	if (!chk(p1, p1_to_p3, p3)) end();
	if (!chk(cue, cue_to_p2, p2)) end();
	if (!chk(cue, cue_to_p1, p1)) end();
	if (!chk(cue, cue_to_p1, p3)) end();
	if (!chk(cue, cue_to_p1, p2)) end();

	printf ("%.2lf %.2lf\n", cue.x, (cue_to_p1 - cue).tan() / M_PI * 180.0);
	
	return 0;
}
