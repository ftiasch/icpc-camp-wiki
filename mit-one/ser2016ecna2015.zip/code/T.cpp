#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
typedef pair<int, int> PII;

#define fi first
#define se second
#define pb push_back
#define mp make_pair
#define pct __builtin_popcount

#define rep(i,l,r) for (int i=(l); i<=(r); i++)
#define repd(i,r,l) for (int i=(r); i>=(l); i--)
#define rept(i,c) for (__typeof((c).begin()) i=((c).begin()); i!=((c).end()); i++)

void lemon()
{
}

#define N 11
int n;
string a[N];
string s;

string b[N];
string c[N];

const string invalid = "invalid grille";

int main() {
	//freopen("","r",stdin);
	lemon();
	cin >> n;
	for (int i = 0; i < n; i ++)
		cin >> a[i];
	for (int i = 0; i < n; i ++) {
		b[i] = string(n, '*');
	}
	cin >> s;
	int u = 0;
	for (int z = 0; z < 4; z ++) {
		for (int i = 0; i < n; i ++)
			for (int j = 0; j < n; j ++)
				if (a[i][j] == '.') {
					if (b[i][j] != '*') {
						cout << invalid << endl;
						return 0;
					} else {
						b[i][j] = s[u];
						u ++;
					}
				}
		for (int i = 0; i < n; i ++)
			c[i] = a[i];
		for (int i = 0; i < n; i ++)
			for (int j = 0; j < n; j ++) {
				a[i][j] = c[n-1-j][i];
			}
	}
	if (u != n*n) {
		cout << invalid << endl;
		return 0;
	}
	string t = "";
	for (int i = 0; i < n; i ++) t += b[i];
	cout << t << endl;
	return 0;
}
