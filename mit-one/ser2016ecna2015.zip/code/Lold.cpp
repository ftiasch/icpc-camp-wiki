#include <bits/stdc++.h>
using namespace std;

typedef long long LL;
typedef pair<int, int> PII;

#define fi first
#define se second
#define pb push_back
#define mp make_pair
#define pct __builtin_popcount

#define rep(i,l,r) for (int i=(l); i<=(r); i++)
#define repd(i,r,l) for (int i=(r); i>=(l); i--)
#define rept(i,c) for (__typeof((c).begin()) i=((c).begin()); i!=((c).end()); i++)

#define INF 2000000000

#define maxn 1010

int ans[4][maxn][maxn];
int ax[maxn], ay[maxn], az[maxn], w[maxn], vx[maxn], vy[maxn], vz[maxn], dim[4];

int lcm(int x, int y)
{
	return x*y/__gcd(x,y);
}


pair<int,int> calc(int p1, int p2, int v1, int v2, int dimN)
{
	//-1 = never intersect
	//-2 = always intersect
	int vdif=v1-v2;
	vdif=(vdif%dim[dimN]+dim[dimN])%dim[dimN];
	int pdif=p2-p1;
	pdif=(pdif%dim[dimN]+dim[dimN])%dim[dimN];
	if (vdif==0 && pdif==0) return make_pair(-2,0);
	if (vdif==0 && pdif!=0) return make_pair(-1,0);
	int z=ans[dimN][vdif][pdif];
	if (z==-1) return make_pair(-1,0);
	int c=lcm(vdif,dim[dimN])/vdif;
	return make_pair(z,c);
}

void gce(int a, int b, int &x, int &y) {
	if (!b) {x = 1; y = 0; return;}
	gce(b, a%b, y, x);
	y-=a/b*x;
}

int inv(int a, int b, int c) {
	int x, y;
	gce(a, c, x, y);
	x = (LL)x*b%c;
	return x<0?x+c:x;
}

PII CRT2() {
	//x % md[i] = rem[i] \forall i\in [0,n-1)
	int m1, r1;
	int m2, r2;
	int m3, r3;
	m1 = md[0];
	r1 = rem[0];
	if (n == 1) {
		m2 = m1;
		r2 = r1;
	} else {
		m2 = md[1];
		r2 = rem[1];
	}
	if (n <= 2) {
		m3 = m2;
		r3 = r2;
	} else {
		m3 = md[2];
		r3 = rem[2];
	}
	
	int g = __gcd(m2, m3);
	if (r2%g != r3%g) return -1;
	m2 /= g;
	r2 %= m2;
	
	g = __gcd(m1, m3);
	if (r1%g != r3%g) return -1;
	m1 /= g;
	r1 %= m1;
	
	g = __gcd(m1, m2);
	if (r1%g != r2%g) return -1;
	m1 /= g;
	r1 %= m1;
	
	assert(__gcd(m1, m2) == 1);
	assert(__gcd(m1, m3) == 1);
	assert(__gcd(m2, m3) == 1);
	
	int S = 0;
	S += inv(m2*m3%m1, r1, m1)*m2*m3;
	S += inv(m1*m3%m2, r2, m2)*m1*m3;
	S += inv(m1*m2%m3, r3, m3)*m1*m2;
	//printf ("%d\n", inv(m1*m2%m3, r3, m3));
	//printf ("%d %d %d %d %d %d\n", m1, m2, m3, r1, r2, r3);
	//printf ("%d\n", S);
	//printf ("%d %d\n", S%m1, r1%m1);
	//printf ("%d %d\n", S%m2, r2%m2);
	//printf ("%d %d\n", S%m3, r3%m3);
	//while(true);
	return S;
}

int CRT(int *rem, int *md, int n)
{
	int m1 = md[0];
	int r1 = rem[0];
	for (int i = 1; i < n; i++) {
		PII w = CRT2(m1, r1, md[i], rem[i]);
		if (w.fi == -1) return -1;
		m1 = w.fi;
		r1 = w.se;
	}
	return r1;
}

int check(int i, int j)
{
	pair<int,int> t1=calc(ax[i],ax[j],vx[i],vx[j],1);
	pair<int,int> t2=calc(ay[i],ay[j],vy[i],vy[j],2);
	pair<int,int> t3=calc(az[i],az[j],vz[i],vz[j],3);
	
	if (t1.first==-1 || t2.first==-1 || t3.first==-1) return INF;
	
	int t[3];
	int md[3];
	int all=0;
	if (t1.first!=-2) t[all]=t1.first, md[all]=t1.second, all++;
	if (t2.first!=-2) t[all]=t2.first, md[all]=t2.second, all++;
	if (t3.first!=-2) t[all]=t3.first, md[all]=t3.second, all++;
	
	int ret=CRT(t,md,all);
	if (ret==-1) return INF;
	return ret;
}

void lemon()
{
	int n; scanf("%d%d%d%d",&n, &dim[1], &dim[2], &dim[3]);
	//build up table for ax=b % c
	rep(dimN,1,3)
	{
		int C=dim[dimN];
		rep(i,0,C-1) rep(j,0,C-1) ans[dimN][i][j]=-1;
		rep(A,1,C-1)
			repd(X,C-1,1)
				ans[dimN][A][A*X%C]=X;
	}
	
	rep(i,1,n) 
	{
		scanf("%d",&w[i]);
		scanf("%d%d%d",&ax[i],&ay[i],&az[i]);
		scanf("%d%d%d",&vx[i],&vy[i],&vz[i]);
	}
	
	while (1)
	{
		int mint=INF;
		rep(i,1,n)
			rep(j,i+1,n)
			{
				int t=check(i,j);
				if (t!=INF)
				{
					int z,z2;
					z=(ax[i]+LL(vx[i])*t)%dim[1];
					z=(z%dim[1]+dim[1])%dim[1];
					z2=(ax[j]+LL(vx[j])*t)%dim[1];
					z2=(z2%dim[1]+dim[1])%dim[1];
					assert(z==z2);
					z=(ay[i]+LL(vy[i])*t)%dim[2];
					z=(z%dim[2]+dim[2])%dim[2];
					z2=(ay[j]+LL(vy[j])*t)%dim[2];
					z2=(z2%dim[2]+dim[2])%dim[2];
					assert(z==z2);
					z=(az[i]+LL(vz[i])*t)%dim[3];
					z=(z%dim[3]+dim[3])%dim[3];
					z2=(az[j]+LL(vz[j])*t)%dim[3];
					z2=(z2%dim[3]+dim[3])%dim[3];
					assert(z==z2);
				}
				if (t<mint) mint=t;
			}
		if (mint==INF) break;
		
		int t=mint;
		rep(i,1,n)
		{
			ax[i]=(ax[i]+LL(vx[i])*t)%dim[1];
			ax[i]=(ax[i]%dim[1]+dim[1])%dim[1];
			ay[i]=(ay[i]+LL(vy[i])*t)%dim[2];
			ay[i]=(ay[i]%dim[2]+dim[2])%dim[2];
			az[i]=(az[i]+LL(vz[i])*t)%dim[3];
			az[i]=(az[i]%dim[3]+dim[3])%dim[3];
		}
		map< pair<int, pair<int, int> >, pair<int, pair< pair<int,int>, pair<int,int> > > > S;
		rep(i,1,n)
		{
			pair< int, pair< pair<int,int>, pair<int,int> > > s=S[make_pair(ax[i],make_pair(ay[i],az[i]))];
			s.first++;
			s.second.first.first+=w[i];
			s.second.first.second+=vx[i];
			s.second.second.first+=vy[i];
			s.second.second.second+=vz[i];
			S[make_pair(ax[i],make_pair(ay[i],az[i]))]=s;
		}
		
		int all=0;
		rept(it,S)
		{
			pair< int, pair<int,int> > ps=it->first;
			pair<int, pair< pair<int,int>, pair<int,int> > > dt=it->second;
			all++;
			ax[all]=ps.first;
			ay[all]=ps.second.first;
			az[all]=ps.second.second;
			int z=dt.first;
			w[all]=dt.second.first.first;
			vx[all]=dt.second.first.second/z;
			vy[all]=dt.second.second.first/z;
			vz[all]=dt.second.second.second/z;
		}
		n=all;
	}
	
	map< pair< pair<int,int>, pair<int,int> >, pair< int, pair<int,int> > > S;
	rep(i,1,n)
		S[make_pair( make_pair(-w[i], ax[i]), make_pair(ay[i],az[i]) )] = make_pair(vx[i], make_pair(vy[i],vz[i]));
	
	printf("%d\n",n);
	int all=0;
	rept(it,S)
	{
		pair< pair<int,int>, pair<int,int> > ps=it->first;
		pair< int, pair<int,int> > dt=it->second;
		printf("P%d: %d %d %d %d %d %d %d\n",all,-ps.first.first, ps.first.second, ps.second.first, ps.second.second, dt.first, dt.second.first, dt.second.second);
		all++;
	}
}

int main() {
	freopen("L.in","r",stdin);
	lemon();
	return 0;
}
