#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
typedef pair<int, int> PII;

#define fi first
#define se second
#define pb push_back
#define mp make_pair
#define pct __builtin_popcount

#define rep(i,l,r) for (int i=(l); i<=(r); i++)
#define repd(i,r,l) for (int i=(r); i>=(l); i--)
#define rept(i,c) for (__typeof((c).begin()) i=((c).begin()); i!=((c).end()); i++)

#define N 110
int r, c, n, m;
int x[N], y[N], cc[N], Left[N], Right[N], up[N], down[N];

int main() {
	//freopen("","r",stdin);
	scanf("%d%d%d%d", &r, &c, &n, &m);
	int nn = n;
	if (r * c < n) {
		return 202;
	}
	int base = 0;
	for (int i = 1; i <= n + m; i++) {
		scanf("%d%d", &x[i], &y[i]);
		x[i] += 7;
		y[i] += 4;
		if (x[i] >= r || y[i] >= c) {
			if (i <= n) {
				base += 1;
				n -= 1;
				i -= 1;
			}else {
				m -= 1;
				i -= 1;
			}
		}
	}
	for (int i = 1; i <= n; i++)
		cc[i] = 1;
	
	
	for (int i = 1; i <= n; i++) {
		Left[i] = Right[i] = x[i];
		up[i] = down[i] = y[i];
	}
	for (int i = n + 1; i <= m; i++) {
		Left[i] = x[i] + 1;
		Right[i] = x[i] - 1;
		up[i] = y[i] + 1;
		down[i] = y[i] - 1;
	}
	for (int i = 1; i <= n + m; i++)
		for (int j = 1; j < i; j++)
			if (down[i] < down[j]) {
				swap(x[i], x[j]);
				swap(y[i], y[j]);
				swap(cc[i], cc[j]);
				swap(Left[i], Left[j]);
				swap(Right[i], Right[j]);
				swap(up[i], up[j]);
				swap(down[i], down[j]);
			}
	Left[0] = 0;
	Right[0] = r - 1;
	up[0] = 0;
	down[0] = c - 1;
	
	
	int ans = n + m;
	for (int i = 0; i <= n + m; i++)
		for (int j = 0; j <= n + m; j++)
			for (int p = 0; p <= n + m; p++)
			if (Right[p] >= Left[j]) {
				int cur = 0, h;
				for (int q = 1; q <= n + m; q = h + 1) {
					for (h = q; h < n + m && down[h + 1] == down[q]; )
						h += 1;
					int cnt = 0;
					for (int t = q; t <= h; t++)
						if (y[t] >= up[i] && Left[j] <= x[t] && Right[p] >= x[t]) {
							if (cc[t] == 1)
								cur += 1;
							else
								cnt += 1;
						}
					if ((Right[p] - Left[j] + 1) * (down[q] - up[i] + 1) >= nn)
						ans = min(ans, n - cur);
					cur -= cnt;
				}
				if ((Right[p] - Left[j] + 1) * (c - up[i]) >= nn)
					ans = min(ans, n - cur);
			}
	printf("%d\n", ans + base);
	return 0;
}
