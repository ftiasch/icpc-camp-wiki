#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef pair<int, int> PII;
typedef long long LL;
typedef unsigned long long ULL;

#define pb push_back
#define fi first
#define se second
#define mp make_pair

#define rep(i,l,r) for (int i=(l); i<=(r); i++)
#define repd(i,r,l) for (int i=(r); i>=(l); i--)
#define rept(i,c) for (__typeof((c).begin()) i=((c).begin()); i!=((c).end()); i++)

struct circle {
	double x,y,r;
};

circle c[50];

#define eps 0

double getarea(circle A, circle B) {
	double d=sqrt((A.x-B.x)*(A.x-B.x)+(A.y-B.y)*(A.y-B.y));
	if (d>=A.r+B.r+eps) return 0;
	if (d<=fabs(A.r-B.r)+eps) {
		double mr=min(A.r,B.r);
		return mr*mr*M_PI;
	}
	double costheta = (A.r*A.r+d*d-B.r*B.r)/(2*A.r*d);
	double theta=acos(costheta);
	double S1=theta*A.r*A.r-A.r*A.r*sin(2*theta)/2;
	costheta = (B.r*B.r+d*d-A.r*A.r)/(2*B.r*d);
	theta=acos(costheta);
	double S2=theta*B.r*B.r-B.r*B.r*sin(2*theta)/2;
	return S1+S2;
}

int check(int i, int j) {
	double area = getarea(c[i],c[j]);
	//printf("%d %d %.10lf\n",i,j,area);
	return area>0.5+eps;
}

vector<int> g[50];

int n;

ULL tvis;
int cc=0;

ULL dfs(int cur) {
	cc++;
	ULL ret = (ULL)1<<cur;
	tvis ^= ret;
	rept(it,g[cur]) 
	{
		ULL mask = (ULL)1<<(*it);
		if (tvis&mask)
		{
			ret |= dfs(*it);
		}
	}
	return ret;
}

vector<ULL> tl;

int find_components(ULL alive) {
	tl.clear();
	tvis = alive;
	int maxcc=0;
	rep(i,1,n) 
		if (tvis&((ULL)1<<i)) 
		{
			cc=0;
			tl.push_back(dfs(i));
			maxcc=max(maxcc,cc);
		}
	return maxcc;
}

pair<int,ULL> solve(ULL alive) {
	if (alive == 0) {
		return make_pair(0,0);
	}
	
	int minz=1000000, minzi;
	rep(i,1,n) {
		ULL mask=(ULL)1<<i;
		if (alive&mask) {
			int z=find_components(alive^mask);
			if (z<minz) {
				minz=z; minzi=i;
			}
		}
	}
	
	int ans1=0; ULL msk1=0;
	alive^=(ULL)1<<minzi;
	find_components(alive);
	vector<ULL> lis=tl;
	rept(it,lis)
	{
		pair<int,ULL> r = solve(*it);
		ans1+=r.first; msk1|=r.second;
	}

	int ans2=1; ULL msk2=(ULL)1<<minzi;
	rept(it,g[minzi]) alive &= (~((ULL)1<<(*it)));
	find_components(alive);
	lis=tl;
	rept(it,lis)
	{
		pair<int,ULL> r = solve(*it);
		ans2+=r.first; msk2|=r.second;
	}
	if (ans1>ans2) return make_pair(ans1,msk1); else return make_pair(ans2,msk2);
}

void lemon() {
	string s;
	getline(cin, s);
	istringstream iss1(s);
	iss1 >> n;

	for (int i = 1; i <= n; i ++) {
		getline(cin, s);
		istringstream iss(s);
		iss >> c[i].x >> c[i].y >> c[i].r;
	}
	
	rep(i,1,n) g[i].clear();
	rep(i,1,n)
		rep(j,i+1,n)
			if (check(i,j))
			{
					//printf("%d %d\n",i,j);
				g[i].push_back(j), g[j].push_back(i);
			}
	
	ULL fullmask=0;
	rep(i,1,n) fullmask |= (ULL)1<<i;
	pair<int, ULL> ans = solve(fullmask);
	printf("%d",ans.first);
	rep(i,1,n) 
		if (ans.second&((ULL)1<<i))
			printf(" %d",i);
	printf("\n");
}

int main() {
	string s;
	while(getline(cin, s)) {
		cout << s << endl;
		lemon();
	}
	return 0;
}

