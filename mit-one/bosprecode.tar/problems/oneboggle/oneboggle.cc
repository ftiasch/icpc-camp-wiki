#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef pair<int, int> PII;
typedef long long LL;
typedef unsigned long long ULL;

#define pb push_back
#define fi first
#define se second
#define mp make_pair

#define rep(i,l,r) for (int i=(l); i<=(r); i++)
#define repd(i,r,l) for (int i=(r); i>=(l); i--)
#define rept(i,c) for (__typeof((c).begin()) i=((c).begin()); i!=((c).end()); i++)

void lemon() {

}

string a[1010]; int n;

int main() {
	string s;
	while (getline(cin, s)) {
		n = 0;
		cout << s << endl;
		while (true) {
			getline(cin, s);
			if (s == "*") break;
			a[n++] = s;
		}
		while (true) {
			getline(cin, s);
			if (s == "*") break;
			string t = string((int)s.length(), '.');
			int sn = (int) s.length();
			for (int i = 0; i < n; i ++) {
				for (int j = 0; j <= sn - (int) a[i].size(); j ++) {
					bool F = true;
					for (int k = 0; k < (int) a[i].size(); k++) {
						if (a[i][k] != s[j+k]) {
							F = false; break;
						}
					}
					if (F) {
						for (int k = 0; k < (int) a[i].size(); k++) {
							t[j+k] = s[j+k];
						}
					}
				}
			}
			reverse(s.begin(), s.end());
			reverse(t.begin(), t.end());
			for (int i = 0; i < n; i ++) {
				for (int j = 0; j <= sn - (int) a[i].size(); j ++) {
					bool F = true;
					for (int k = 0; k < (int) a[i].size(); k++) {
						if (a[i][k] != s[j+k]) {
							F = false; break;
						}
					}
					if (F) {
						for (int k = 0; k < (int) a[i].size(); k++) {
							t[j+k] = s[j+k];
						}
					}
				}
			}
			reverse(s.begin(), s.end());
			reverse(t.begin(), t.end());
			cout << t << endl;
		}
	}
	lemon();
	return 0;
}

