#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef pair<int, int> PII;
typedef long long LL;
typedef unsigned long long ULL;

#define pb push_back
#define fi first
#define se second
#define mp make_pair

#define rep(i,l,r) for (int i=(l); i<=(r); i++)
#define repd(i,r,l) for (int i=(r); i>=(l); i--)
#define rept(i,c) for (__typeof((c).begin()) i=((c).begin()); i!=((c).end()); i++)

void lemon() {

}

int main() {
	string ss;
	while(getline(cin, ss)) {
		string s;
		getline(cin, s);
		istringstream iss1(s);
		iss1 >> n >> m;
		s = n + 1;
		t = n + 2;
		S = n + 3;
		T = n + 4;
		len = 1;
		for (int i = 1; i <= n + 4; i++)
			till[i] = 0;
		for (int i = 1; i <= n; i++) {
			string s1;
			getline(cin, s1);
			istringtream iss2(s);
			int x, y;
			iss2 >> x >> y;
			Ad(s, i, x, 0);
			Ad(i, t, y, 0);
		}
		while (m--) {
			
		}
	}
	return 0;
}
