#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef pair<int, int> PII;
typedef long long LL;
typedef unsigned long long ULL;

#define pb push_back
#define fi first
#define se second
#define mp make_pair

#define rep(i,l,r) for (int i=(l); i<=(r); i++)
#define repd(i,r,l) for (int i=(r); i>=(l); i--)
#define rept(i,c) for (__typeof((c).begin()) i=((c).begin()); i!=((c).end()); i++)

void lemon() {

}
const double eps = 1e-8;

#define N 500
#define M 500

int n, m;
double od[N], id[N];
int px[M], py[M]; double cap[M], co[M], mic[M];

vector<double> simplex(vector<vector<double> > A, vector<double> b, vector<double> c) {
	int n = (int) A.size(); 
	int m = (int) A[0].size() + 1;
	int r = n;
	int s = m-1;
	vector<vector<double> > D = vector<vector<double> > (n+2, vector<double> (m+1));
	vector<int> ix = vector<int> (n+m);
	for (int i = 0; i < n+m; i ++) ix[i] = i;
	for (int i = 0; i < n; i ++) {
		for (int j = 0; j < m-1; j ++) D[i][j] = -A[i][j];
		D[i][m-1] = 1;
		D[i][m] = b[i];
		if (D[r][m] > D[i][m]) r = i;
	}
	for (int j = 0; j < m-1; j ++) D[n][j] = c[j];
	D[n+1][m-1] = -1; int z = 0;
	for (double d;;) {
		if (r<n) {
			swap(ix[s], ix[r+m]);
			D[r][s] = 1.0/D[r][s];
			for (int j = 0; j <= m; j ++) if (j != s) D[r][j] *= -D[r][s];
			for (int i = 0; i <= n+1; i ++) if (i != r) {
				for (int j = 0; j <= m; j ++) if (j != s) D[i][j] += D[r][j] * D[i][s];
				D[i][s] *= D[r][s];
			}
		}
		r = -1;
		s = -1;
		for (int j = 0; j < m; j ++) if (s < 0 || ix[s] > ix[j]) {
			if (D[n+1][j] > eps || D[n+1][j] > -eps && D[n][j] > eps) s = j;
		}
		if (s < 0) break;
		for (int i = 0; i < n; i ++) if (D[i][s] < -eps) {
			if (r < 0 || (d = D[r][m]/D[r][s]-D[i][m]/D[i][s]) < -eps || 
				d < eps && ix[r+m] > ix[i+m]) r = i;
			// if (r < 0) return vector<double>();
		}
		if (r < 0) return vector<double>();
	}
	if (D[n+1][m] < -eps) return vector<double>();
	vector<double> x(m-1);
	for (int i = m; i < n+m; i ++) if (ix[i] < m-1) x[ix[i]] = D[i-m][m];
	printf ("%.2lf\n", D[n][m]);
	return x;
}

double g[500][200];
double rhs[500];

int main() {
	string ss;
	while(getline(cin, ss)) {
		cout << ss << endl;
		string s;
		getline(cin, s);
		istringstream iss1(s);
		iss1 >> n >> m;
		for (int i = 0; i < n; i ++) {
			getline(cin, s);
			istringstream iss(s);
			iss >> od[i] >> id[i];
		}
		for (int i = 0; i < m; i ++) {
			getline(cin, s);
			istringstream iss(s);
			iss >> px[i] >> py[i] >> cap[i] >> co[i] >> mic[i];
			px[i]--; py[i]--; co[i]=-co[i];
		}
		//source = n
		//sink = n+1
		rep(i,0,n-1) {
			px[m]=n; py[m]=	i; cap[m]=od[i]; co[m]=1; mic[m]=0;
			m++;
		}
		rep(i,0,n-1) {
			px[m]=i; py[m]=n+1; cap[m]=id[i]; co[m]=0; mic[m]=0;
			m++;
		}
		n+=2;

		//source n-2, sink n-1
		//variable num m
		memset(g,0,sizeof g);
		rep(i,0,n-3) { 
			rep(j,0,m-1)
				if (px[j]==i) {
					g[2*i][j]++;
					g[2*i+1][j]--;
				} 
				else if (py[j]==i){
					g[2*i][j]--;
					g[2*i+1][j]++;
				}
			rhs[2*i]=0;
			rhs[2*i+1]=0;
		}
		
		rep(i,0,m-1) {
			g[2*n-4+i][i]--;
			rhs[2*n-4+i]=-mic[i];
		}

		rep(i,0,m-1) {
			g[2*n-4+m+i][i]++;
			rhs[2*n-4+m+i]=cap[i];
		}

		int total_lines = 2*n-4+2*m;
		//solve g*x<=rhs
		//maximize co * x
		
		vector< vector<double> > A;
		A.resize(total_lines);
		rep(i,0,total_lines-1) A[i].resize(m);
		rep(i,0,total_lines-1)
			rep(j,0,m-1)
				A[i][j]=g[i][j];
		
		vector<double> b;
		b.resize(total_lines);
		rep(i,0,total_lines-1) b[i]=rhs[i];

		vector<double> c;
		c.resize(m);
		rep(i,0,m-1) c[i]=co[i];
		if (simplex(A, b, c).empty()) {
			cout << "Mafiosi prevent solution!" << endl;
		}

	}
	return 0;
}
