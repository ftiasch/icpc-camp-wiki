#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef pair<int, int> PII;
typedef long long LL;
typedef unsigned long long ULL;

#define pb push_back
#define fi first
#define se second
#define mp make_pair

#define rep(i,l,r) for (int i=(l); i<=(r); i++)
#define repd(i,r,l) for (int i=(r); i>=(l); i--)
#define rept(i,c) for (__typeof((c).begin()) i=((c).begin()); i!=((c).end()); i++)

void lemon() {

}

const int nn = 100000;

int a[22];
const int mod = 10000007;

int main() {
	string s;
	while (getline(cin, s)) {
		istringstream iss(s);
		int n; double d;
		iss >> n >> d;
		int S = 0;
		for (int i = 0; i < nn; i ++) {
			for (int j = 0; j < n; j ++) {
				a[j] = rand()%mod;
			}
			sort(a, a+n);
			bool F = true;
			for (int j = 0; j < n-1; j ++) 
				if (a[j+1]-a[j] < d*mod) F = false;
			if (!F) S++;
		}
		printf ("%d %.4lf %.2lf\n", n, d, (double) S/nn);
	}
	lemon();
	return 0;
}

