#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef pair<int, int> PII;
typedef long long LL;
typedef unsigned long long ULL;

#define pb push_back
#define fi first
#define se second
#define mp make_pair

#define rep(i,l,r) for (int i=(l); i<=(r); i++)
#define repd(i,r,l) for (int i=(r); i>=(l); i--)
#define rept(i,c) for (__typeof((c).begin()) i=((c).begin()); i!=((c).end()); i++)

void lemon() {

}

map<string, int> animal;
map<string, int> color;
vector< pair< vector<string>, vector<string> > > A;
vector<pair<PII, PII > > B;

vector<string> arra;
vector<string> arrc;

int na, nc;

int adda(string a) {
	if (animal.find(a) == animal.end()) {
		arra.pb(a);
		animal[a]  = na++;
	}
	return animal[a];
}

int addc(string c) {
	if (color.find(c) == color.end()) {
		arrc.pb(c);
		color[c] = nc++;
	}
	return color[c];
}

int can[20];
int nw[20];

void val() {
	for (int i = 0; i < (int) B.size(); i ++) {
		int x1 = B[i].fi.fi;
		int y1 = B[i].fi.se;
		int x2 = B[i].se.fi;
		int y2 = B[i].se.se;
		if ((y1 >> nw[x1]) &1) {
			if (!((y2 >> nw[x2]) &1)) {
				return;
			}
		}
	}
	for (int i = 0; i < na; i ++) 
		can[i] |= (1<<nw[i]);
}

void ff(int x) {
	if (x == na) {
		val();
		return;
	}
	for (int i = 0; i < nc; i ++) {
		nw[x] = i;
		ff(x+1);
	}
}

int main() {
	string s; string u;
	while (getline(cin, s)) {
		cout << s << endl;
		animal.clear();
		color.clear();
		A.clear();
		B.clear();
		arra.clear();
		arrc.clear();
		while (true) {
			string s;
			getline(cin, s);
			//cout << s << endl;
			if (s == "*") break;
			istringstream iss(s);
			iss >> u;
			iss >> u;
			vector<string> a;
			iss >> u;
			a.pb(u);
			//cout << u << endl;
			iss >> u;
			while (true) {
				iss >> u;
				bool F = false;
				if (u[(int) u.length()-1] == ',') {
					u = u.substr(0, (int) u.length()-1);
					F = true;
				}
				if (u == "or") continue;
				a.pb(u);
				if (F) break;
			}
			iss >> u;
			iss >> u;
			vector<string> b;
			iss >> u;
			b.pb(u);
			iss >> u;
			while (iss >> u) {
				if (u == "or") continue;
				b.pb(u);
			}
			A.pb(mp(a, b));
		}
		na = 0;
		nc = 0;
		for (int i = 0; i < (int) A.size(); i++) {
			int x1 = adda(A[i].fi[0]);
			int y1 = 0;
			int x2 = adda(A[i].se[0]);
			int y2 = 0;
			for (int j = 1; j < (int) A[i].fi.size(); j ++)
				y1 |= (1 << addc(A[i].fi[j]));
			for (int j = 1; j < (int) A[i].se.size(); j ++) 
				y2 |= (1 << addc(A[i].se[j]));
			B.pb(mp(mp(x1, y1), mp(x2, y2)));
		}
		memset(can, 0, sizeof can);
		ff(0);
		for (int i = 0; i < na; i ++) {
			cout << "the ";
			cout << arra[i];
			cout << " is ";
			bool first = true;
			for (int j = 0; j < nc; j ++) 
				if ((can[i] >> j) &1) {
					if (!first) cout << " or ";
					cout << arrc[j];
						first = false;
				}
			cout << endl;
		}
	}
}

