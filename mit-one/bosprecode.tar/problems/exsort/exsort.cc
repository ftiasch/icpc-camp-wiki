#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef pair<int, int> PII;
typedef long long LL;
typedef unsigned long long ULL;

#define pb push_back
#define fi first
#define se second
#define mp make_pair

#define rep(i,l,r) for (int i=(l); i<=(r); i++)
#define repd(i,r,l) for (int i=(r); i>=(l); i--)
#define rept(i,c) for (__typeof((c).begin()) i=((c).begin()); i!=((c).end()); i++)

int B;

pair<int,int> t[20];

struct Maintainer
{
	int buf[20], pos[20], which, ptr, cur, end, need_sort;

	void init(int _cur, int _end, int _which, int _need_sort) {
		ptr = B; cur = _cur; end = _end; which = _which; need_sort = _need_sort;
	}

	int is_end() {
		return (ptr==B && cur==end);
	}

	int next() {
		if (ptr==B) {
			printf("read %d %d\n", cur, which);
			fflush(stdout);
			rep(i,0,B-1) scanf("%d",&buf[i]);
			ptr=0;
			cur++;
			if (need_sort) {
				rep(i,0,B-1) t[i]=make_pair(buf[i],i);
				sort(t,t+B);
				rep(i,0,B-1) buf[i]=t[i].first, pos[i]=t[i].second;
			} else {
				rep(i,0,B-1) pos[i]=i;
			}
		}
		ptr++;
		return buf[ptr-1];
	}
};

int C;
Maintainer M[100];
int val[100], exist[100];

void solve(int src, int dst, int block, int start, int end, int need_sort) {
	int num = 0, _s = start;
	while (start<end) {
		M[num].init(src+start, min(src+end, src+start+block), num, need_sort);
		val[num]=M[num].next();
		exist[num]=1;
		num++;
		start+=block;
	}
	start = _s;
	rep(i,0,(end-start)*B-1) {
		int first=1, minv=0, mini=0;
		rep(j,0,num-1)
			if (exist[j] && (first || val[j]<minv)) {
				minv=val[j], mini=j;
				first=0;
			}

		printf("move %d %d %d %d\n",mini,M[mini].pos[M[mini].ptr-1],C,i%B);
		fflush(stdout);
		if (M[mini].is_end()) {
			exist[mini]=0;
		} else {
			val[mini]=M[mini].next();
		}
		if (i%B==B-1) {
			printf("write %d %d\n",C,dst+start+i/B);
			fflush(stdout);
		}
	}
}

bool lemon() {
	printf("case\n");
	fflush(stdout);
	int I,D,K;
	scanf("%d%d%d%d%d",&B,&D,&C,&I,&K);
	if (B==0 && D==0 && C==0 && I==0 && K==0) return false;
	C--;
	int now=0, cur;
	if (K%2==0) cur=1; else cur=0;
	int nowC=1;
	rep(i,1,K) {
		int S=0;
		while (S<I) {
			solve(now*I, cur*I, nowC, S, min(S+nowC*C, I), (i==1?1:0));
			S+=nowC*C;
		}
		cur=1-cur;
		now=1-cur;
		nowC*=C;
	}
	return true;
}

int main() {
	while (lemon());
	return 0;
}

