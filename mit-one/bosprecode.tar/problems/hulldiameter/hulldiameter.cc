#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef pair<int, int> PII;
typedef long long LL;
typedef unsigned long long ULL;

#define pb push_back
#define fi first
#define se second
#define mp make_pair

#define rep(i,l,r) for (int i=(l); i<=(r); i++)
#define repd(i,r,l) for (int i=(r); i>=(l); i--)
#define rept(i,c) for (__typeof((c).begin()) i=((c).begin()); i!=((c).end()); i++)


int n;
double x[310000];
double y[310000];
int ansx, ansy;
double ans;

void lemon() {

}

void UPD(int i, int j) {
	i %= n;
	j %= n;
	if (i > j)
		swap(i, j);
	double d = sqrt((x[i] - x[j]) * (x[i] - x[j]) + (y[i] - y[j]) * (y[i] - y[j]));
	if (d > ans) {
		ans = d;
		ansx = i + 1;
		ansy = j + 1;
	}
}


double cp(double X1, double Y1, double X2, double Y2) {
	return X1 * Y2 - X2 * Y1;
}

int main() {
	string test;
	while (getline(cin, test)) {
		string s;
		getline(cin, s);
		istringstream iss1(s);
		iss1 >> n;
		for (int i = 0; i < n; i ++) {
			getline(cin, s);
			istringstream iss(s);
			iss >> x[i] >> y[i];
		}
		for (int i = n; i < 3 * n; i++)
			x[i] = x[i - n], y[i] = y[i - n];
		ans = -1;
		for (int i = 1; i < n; i++)
			UPD(0, i);
		int t;
		t = ansx;
		for (int i = 1; i < n; i++) {
			while (true) {
				UPD(i, t);
				if (t % n != i % n && cp(x[t + 1] - x[t], y[t + 1] - y[t], x[i] - x[i + 1], y[i] - y[i + 1]) >= 0)
					break;
				t++;
			}
		}
		//cout << test << endl;
		printf("%s\n", test.c_str());
		printf("%.9lf %d %d\n", ans, ansx, ansy);
	}
	lemon();
	return 0;
}

