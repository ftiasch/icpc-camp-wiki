#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef pair<int, int> PII;
typedef long long LL;
typedef unsigned long long ULL;

#define pb push_back
#define fi first
#define se second
#define mp make_pair

#define rep(i,l,r) for (int i=(l); i<=(r); i++)
#define repd(i,r,l) for (int i=(r); i>=(l); i--)
#define rept(i,c) for (__typeof((c).begin()) i=((c).begin()); i!=((c).end()); i++)

int len;
string a[100];
bool sin_wave;
int mi, ma, ans;

void lemon() {

}

int main() {
	string TEST;
	while (getline(cin, TEST)) {
		//cout << TEST << endl;
		len = 0;
		while (true) {
			string x;
			getline(cin, x);
			if (x == "*")
				break;
			a[++len] = x;
		}
		for (int i = 1; i <= len; i++) {
			bool have = false;
			for (int j = 0; j < (int) a[i].size(); j++)
				if (a[i][j] == 'x')
					have = true;
			if (have)
				ma = i;
		}
		for (int i = len; i; i--) {
			bool have = false;
			for (int j = 0; j < (int) a[i].size(); j++)
				if (a[i][j] == 'x')
					have = true;
			if (have)
				mi = i;
		
		}
		sin_wave = false;
		for (int i = mi + 1; i < ma; i++) {
			bool have = false;
			for (int j = 0; j < (int) a[i].size(); j++)
				if (a[i][j] == 'x')
					have = true;
			if (have)
				sin_wave = true;
		}
		int p1 = 0;
		for (int i = 0; i < (int) a[mi].size(); i++) {
			if (a[mi][i] == 'x' && a[mi][i + 1] == ' ') {
				if (!p1)
					p1 = i;
				else {
					ans = i - p1;
					break;
				}
			}
		}
		cout << TEST << endl;
		if (sin_wave)
			printf("sine ");
		else
			printf("square ");
		printf("%d\n", ans);
	}
	return 0;
}

