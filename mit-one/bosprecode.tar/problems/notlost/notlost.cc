#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef pair<int, int> PII;
typedef long long LL;
typedef unsigned long long ULL;

#define pb push_back
#define fi first
#define se second
#define mp make_pair

#define rep(i,l,r) for (int i=(l); i<=(r); i++)
#define repd(i,r,l) for (int i=(r); i>=(l); i--)
#define rept(i,c) for (__typeof((c).begin()) i=((c).begin()); i!=((c).end()); i++)

#define pi 3.1415926535897932384626

void lemon() {

}
double X, Y;
double ans;
int main() {
	string test;
	while (getline(cin, test)) {
		string s;
		X = Y = 0;
		while (true) {
			getline(cin, s);
			if (s == "*") break;
			istringstream iss(s);
			double x, y;
			iss >> x >> y;
			X += cos(x / 360 * 2 * pi) * y;
			Y += sin(x / 360 * 2 * pi) * y;
		}
		cout << test << endl;
		ans = atan2(Y, X) / pi * 180 + 180;
		//if (ans < 0)
		//	ans += 360;
		cout << ans << ' ' << sqrt(X * X + Y * Y) <<endl;;
	}
	lemon();
	return 0;
}

