#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef pair<int, int> PII;
typedef long long LL;
typedef unsigned long long ULL;

#define pb push_back
#define fi first
#define se second
#define mp make_pair

#define rep(i,l,r) for (int i=(l); i<=(r); i++)
#define repd(i,r,l) for (int i=(r); i>=(l); i--)
#define rept(i,c) for (__typeof((c).begin()) i=((c).begin()); i!=((c).end()); i++)

void lemon() {

}


const int PP = 131;
const int P1 = 1000000007;

#define N 20010
int p1[N];
string s, t;
int a[N], n;
int b[N], m;
int p[N];

void blt(int n, int* a, const string& s) {
	a[0] = 0;
	for (int i = 0; i < n; i ++) {
		a[i+1] = ((ll)a[i]*PP+(s[i]-'A'))%P1;
	}
}

int hha(int x, int l) {
	return (a[x+l]-(ll)a[x]*p1[l]%P1+P1)%P1;
}

int hhb(int l) {
	return b[l];
}

int lcpa(int x, int y) {
	int l = 1, r = min(n-x, n-y);
	while (l <= r) {
		int mid = (l+r)/2;
		if (hha(x, mid) == hha(y, mid)) l = mid+1;
		else r = mid-1;
	}
	return r;
}

bool cmpa(int x, int y) {
	int l = lcpa(x, y);
	if (x+l == n) return true;
	if (y+l == n) return false;
	return s[x+l] < s[y+l];
}

int lcpb(int x) {
	int l = 1, r = min(n-x, m);
	while (l <= r) {
		int mid = (l+r)/2;
		if (hha(x, mid) == hhb(mid)) l = mid+1;
		else r = mid-1;
	}
	return r;
}

bool cmpb(int x, bool f) {
	int l = lcpb(x);
	if (l == m) return f;
	if (x+l == n) return false;
	return t[l] < s[x+l];
}

int fl() {
	int l = 0, r = n-1;
	while (l <= r) {
		int mid = (l+r)/2;
		if (cmpb(p[mid], true)) r = mid-1;
		else l = mid+1;
	}
	return l;
}

int fr() {
	int l = 0, r = n-1;
	while (l <= r) {
		int mid = (l+r)/2;
		if (cmpb(p[mid], false)) r = mid-1;
		else l = mid+1;
	}
	return l;
}

int main() {
	p1[0] = 1;
	for (int i = 1; i < N; i ++)
		p1[i] = (ll)p1[i-1]*PP%P1;
	string ss;
	while (getline(cin, ss)) {
		cout << ss << endl;
		getline(cin, s);
		n = (int) s.length();
		blt(n, a, s);
		for (int i = 0; i < n; i ++) p[i] = i;
		sort(p, p+n, cmpa);
		//for (int i = 0; i < n; i ++) printf ("%s\n", s.substr(p[i]).c_str());
		while (true) {
			getline(cin, t);
			if (t == "*") break;
			//continue;
			m = (int) t.length();
			blt(m, b, t);
			int left = fl();
			int right = fr();
			cout << (int) t.length() << " ";
			cout << right - left;
			for (int i = left; i < right; i++) 
				cout << " " << p[i];
			cout << endl;
		}
	}
	return 0;
}
