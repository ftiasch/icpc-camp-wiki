#include <bits/stdc++.h>
using namespace std;

typedef pair<int, int> PII;
typedef long long ll;

#define fi first
#define se second
#define mp make_pair
#define pb push_back

#define N 110
int n, m;
map<string, int> F;
ll a[N][N];

int v[N];

int main() {
	cin >> n >> m;
	n ++;
	F["English"] = 0;
	for (int i = 1; i < n; i ++) {
		string s; cin >> s;
		F[s] = i;
	}
	memset(a, -1, sizeof a);
	for (int i = 0; i < m; i ++) {
		string s, t;
		cin >> s >> t;
		int x = F[s], y = F[t];
		int z; cin >> z;
		a[x][y] = z;
		a[y][x] = z;
	}
	
	ll S = 0;
	memset(v, -1, sizeof v);
	v[0] = 0;
	for (int t = 0; t < n; t ++) {
		for (int i = 0; i < n; i ++)
			if (v[i] == -1) {
				ll T = -1;
				for (int j = 0; j < n; j ++)
					if (v[j] == t && a[j][i] != -1) {
						v[i] = t+1;
						if (T == -1) T = a[j][i]; else T = min(T, a[j][i]);
					}
				if (T != -1) S += T;
			}
	}
	bool F = true;
	for (int i = 0; i < n; i ++) if (v[i] == -1) F = false;
	if (F) cout << S << endl;
	else puts ("Impossible");
	return 0;
}
