#include <bits/stdc++.h>
using namespace std;

typedef pair<int, int> PII;
typedef long long ll;

#define fi first
#define se second
#define mp make_pair
#define pb push_back

#define N 110
int wa[N][N];
int wb[N][N];
int s[N][N];
int la[N], lb[N];
int n, m;

// 1 - yes
// 0 - no

int w[N];
int sa[N];
bool st[N];
bool f[N][N][2];

bool ff(int*a, int l, int n) {
	sa[0] = 0;
	for (int i = 0; i < l; i ++)
		sa[i+1] = sa[i] + a[i];
	int m = sa[l];
	memset(st, 0, sizeof st);
	for (int i = 0; i <= l; i ++)
		st[sa[i]] = 1;
	
	bool F = false;
	memset(f, 0, sizeof f);
	f[0][0][0] = true;
	// 0: can do
	// 1: cannot do, or ongoing
	for (int i = 0; i < n; i ++)
		for (int j = 0; j <= m; j ++) {
			if (f[i][j][1]) {
				if (st[j] && w[i] != 1) f[i+1][j][0] = true;
				if (!st[j] && w[i] != -1) f[i+1][j+1][1] = true;
			}
			if (f[i][j][0]) {
				if (st[j] && w[i] != 1) f[i+1][j][0] = true;
				if (j != m && w[i] != -1) f[i+1][j+1][1] = true;
			}
		}
	for (int j = 0; j < m; j ++)
		f[n][j][0] = f[n][j][1] = false;
	for (int i = n-1; i >= 0; i --) {
		bool cp = false, cn = false;
		for (int j = 0; j <= m; j ++) {
			bool g1 = false, g0 = false;
			if (f[i][j][1]) {
				if (st[j] && w[i] != 1 && f[i+1][j][0]) g1 = cn = true;
				if (!st[j] && w[i] != -1 && f[i+1][j+1][1]) g1 = cp = true;
				f[i][j][1] = g1;
			}
			if (f[i][j][0]) {
				if (st[j] && w[i] != 1 && f[i+1][j][0]) g0 = cn = true;
				if (j != m && w[i] != -1 && f[i+1][j+1][1]) g0 = cp = true;
				f[i][j][0] = g0;
			}
		}
		if (cp && !cn && w[i] != 1) {F = true; w[i] = 1;}
		if (cn && !cp && w[i] != -1) {F = true; w[i] = -1;}
	}
	return F;
}

int main() {
	cin >> n >> m;
	for (int i = 0; i < n; i ++) {
		cin >> la[i];
		for (int j = 0; j < la[i]; j ++) 
			cin >> wa[i][j];
	}
	for (int i = 0; i < m; i ++) {
		cin >> lb[i];
		for (int j = 0; j < lb[i]; j ++)
			cin >> wb[i][j];
	}
	
	while (true) {
		bool F = false;
		for (int i = 0; i < n; i ++) {
			for (int j = 0; j < m; j ++)
				w[j] = s[i][j];
			if (ff(wa[i], la[i], m)) {
				F = true;
				for (int j = 0; j < m; j ++)
					s[i][j] = w[j];
			}
		}
		for (int i = 0; i < m; i ++) {
			for (int j = 0; j < n; j ++) 
				w[j] = s[j][i];
			if (ff(wb[i], lb[i], n)) {
				F = true;
				for (int j = 0; j < n; j ++)
					s[j][i] = w[j];
			}
		}
		if (!F) break;
	}
	for (int i = 0; i < n; i ++) {
		for (int j = 0; j < m; j ++) {
			if (s[i][j] == -1) putchar('.'); else
			if (s[i][j] == 0) putchar('?'); else
			if (s[i][j] == 1) putchar('X');
		}
		puts ("");
	}
	return 0;
}
