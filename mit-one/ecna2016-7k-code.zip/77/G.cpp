#include <bits/stdc++.h>
using namespace std;

typedef pair<int, int> PII;
typedef long long ll;

#define fi first
#define se second
#define mp make_pair
#define pb push_back

#define N 55
int a[N], n;

void end() {
	puts ("No");
	exit(0);
}

void get(int x) {
	int l; cin >> l;
	int la = N;
	while (l--) {
		int y; cin >> y;
		n = max(n, y);
		if (a[y-1] != -1) end();
		if (y > la) end();
		a[y-1] = x;
		la = y;
	}
}

ll ff(int l, int r, int c) {
	if (c == 0) {
		if (a[c] == l) return 1;
		if (a[c] == r) return 0;
		end();
	}
	
	if (a[c] == l) return (1LL << c) + ff(l, 3-l-r, c-1);
	if (a[c] == r) return ff(3-l-r, r, c-1);
	end();
}

int main() {
	memset(a, -1, sizeof a);
	get(0); get(1); get(2);
	cout << ff(0, 2, n-1) << endl;
	return 0;
}
