#include <bits/stdc++.h>
using namespace std;

typedef pair<int, int> PII;
typedef long long ll;

#define fi first
#define se second
#define mp make_pair
#define pb push_back

string s;
int n;

int chk(string t) {
	int m = (int) t.length();
	int S = n+m;
	for (int i = 0; i <= n-m;) {
		if (s.substr(i, m) == t) {
			i += m;
			S -= m-1;
		} else i++;
	}
	return S;
}

int main() {
	cin >> s;
	n = (int) s.length();
	int S = n;
	for (int i = 0; i < n; i ++)
		for (int j = i+1; j <= n; j++) {
			string t = s.substr(i, j-i);
			S = min(S, chk(t));
		}
	printf ("%d\n", S);
	return 0;
}
