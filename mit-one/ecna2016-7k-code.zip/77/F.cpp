#include <bits/stdc++.h>
using namespace std;

typedef pair<int, int> PII;
typedef long long ll;

#define fi first
#define se second
#define mp make_pair
#define pb push_back

#define INF 1000000007
#define N 110
int n, a[N];
int f[N][N];

int gcd(int x, int y) {
	if (y == 0) return x;
	return gcd(y, x%y);
}

int ff(int x, int y) {
	if ((y-x+n)%n <= 1) return 0;
	if (f[x][y] != -1) return f[x][y];
	int &S = f[x][y];
	S = INF;
	int i = (x+1)%n;
	while (i != y) {
		S = min(S, ff(x, i) + ff(i, y));
		(i += 1) %= n;
	}
	S += gcd(a[x], a[y]);
	return S;
}

int main() {
	while (true) {
		cin >> n;
		if (n == 0) break;
		for (int i = 0; i < n; i ++) cin >> a[i];
		int S = INF;
		memset(f, -1, sizeof f);
		for (int i = 0; i < n; i ++)
			for (int j = i+1; j < n; j ++)
				S = min(S, ff(i, j) + ff(j, i) + gcd(a[i], a[j]));
		printf ("%d\n", S);
	}
	return 0;
}
