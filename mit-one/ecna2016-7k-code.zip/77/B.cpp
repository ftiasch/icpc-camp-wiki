#include <bits/stdc++.h>
using namespace std;

typedef pair<int, int> PII;
typedef long long ll;

#define fi first
#define se second
#define mp make_pair
#define pb push_back

#define N 10
string a[N], s;
int n, m;
vector<PII> S;
int L;

int wo = 0, bo = 1, wd = 2, bd = 3;
int wi0 = 0, bi0 = 1, wi1 = 2, bi1 = 3;
int cw = 0, cb = 0;

void upd() {
	if (cw > L) S.clear();
	L = max(L, cw);
	if (cw >= L) S.pb(mp(wi0, wi1));
	
	if (cb > L) S.clear();
	L = max(L, cb);
	if (cb >= L) S.pb(mp(bi0, bi1));
}
queue<int> q;

int main() {
	cin >> n;
	for (int i = 0; i < n; i ++) cin >> a[i];
	for (int i = 4; i < n; i ++) q.push(i);
	cin >> s;
	m = (int) s.length();
	for (int i = 0; i < m; i ++) {
		if (s[i] == 'W') {
			cw ++;
			cb = 0;
			swap(wo, wd);
			q.push(bd);
			bd = bo;
			bo = q.front();
			q.pop();
			bi0 = bd;
			bi1 = bo;
		} else {
			cb ++;
			cw = 0;
			swap(bo, bd);
			q.push(wd);
			wd = wo;
			wo = q.front();
			q.pop();
			wi0 = wd;
			wi1 = wo;
		}
		upd();
	}
	for (int i = 0; i < (int) S.size(); i ++) {
		cout << a[S[i].fi] << " " << a[S[i].se] << endl;
	}
	return 0;
}
