#include <bits/stdc++.h>
using namespace std;

typedef pair<int, int> PII;
typedef long long ll;

#define fi first
#define se second
#define mp make_pair
#define pb push_back

#define N 22
const double eps = 1e-6;

struct P {
	int x, y;
	P(){}
	P(int _x, int _y):x(_x),y(_y){}
	P operator + (const P&a) const {return P(x+a.x, y+a.y);}
	P operator - (const P&a) const {return P(x-a.x, y-a.y);}
	int dot (const P&a) const {return x*a.x+y*a.y;}
	int crs (const P&a) const {return x*a.y-y*a.x;}
	int abs2 () const {return x*x+y*y;}
	int dis2 (const P&a) const {return (x-a.x)*(x-a.x)+(y-a.y)*(y-a.y);}
};

struct PD {
	double x, y;
	PD(){}
	PD(double _x, double _y):x(_x),y(_y){}
	PD operator + (const PD&a) const {return PD(x+a.x, y+a.y);}
	PD operator - (const PD&a) const {return PD(x-a.x, y-a.y);}
	PD operator * (double a) const {return PD(x*a, y*a);}
	PD operator / (double a) const {return PD(x/a, y/a);}
	double dot (const PD&a) const {return x*a.x+y*a.y;}
	double crs (const PD&a) const {return x*a.y-y*a.x;}
	double abs2 () const {return x*x+y*y;}
	double abs () const {return sqrt(abs2());}
	double dis2 (const PD&a) const {return (x-a.x)*(x-a.x)+(y-a.y)*(y-a.y);}
	PD perp() {return PD(y,-x);}
	double tan() {return atan2(y, x);}
};

struct C {
	P a; int r;
};

struct G {
	C a; int h, v;
} a[N];

int n;
bool full[N];
double cv[N]; // current volume
double sp[N]; // increase speed
double b[N][N]; // i -> j percent

struct E {
	double t; int c;
	E(){}
	E(double _t, int _c):t(_t), c(_c){}
	
	bool operator < (const E&a) const {return t < a.t;}
};

vector<E> EL;
bool v[N];

void addE(double le, double ri, int c) {
	if (ri - le < eps) return;
	EL.pb(E(le, c));
	EL.pb(E(ri, -c-1));
}

void chk(C a, C b, int c) {
	int d2 = a.a.dis2(b.a);
	if (d2 >= (a.r + b.r)*(a.r+b.r)) return;
	if (d2 <= (a.r-b.r)*(a.r-b.r)) {
		if (a.r < b.r) {
			addE(0, 1, c);
		}
		return;
	}
	
	PD ap = PD(a.a.x, a.a.y), bp = PD(b.a.x, b.a.y);
	int ar = a.r, br = b.r;
	
	double d = sqrt(d2);
	double x = (d2 - br*br + ar*ar)/(2*d);
	double y = sqrt(max(0.0, ar*ar-x*x));
	PD v = bp-ap;
	double le = (v*x+v.perp()*y).tan();
	double ri = (v*x-v.perp()*y).tan();
	le /= M_PI*2;
	ri /= M_PI*2;
	while (le < -eps) le += 1;
	while (ri < -eps) ri += 1;
	if (le > ri + eps) {
		addE(le, 1, c);
		addE(0, ri, c); 
	} else {
		addE(le, ri, c);
	}
}

int main() {
	cin >> n;
	for (int i = 0; i < n; i ++) {
		cin >> a[i].a.a.x >> a[i].a.a.y >> a[i].h >> a[i].a.r >> a[i].v;
	}
	for (int i = 0; i < n; i ++)
		for (int j = i+1; j < n; j ++)
			if (a[i].h < a[j].h) swap(a[i], a[j]);
	
	for (int i = 0; i < n; i ++) {
		EL.clear();
		for (int j = i+1; j < n; j ++)
			if (a[i].h > a[j].h) chk(a[i].a, a[j].a, j);
		sort(EL.begin(), EL.end());
		memset(v, 0, sizeof v);
		double la = 0;
		for (vector<E>::iterator j = EL.begin(); j != EL.end(); j++) {
			int be = -1;
			for (int k = 0; k < n; k++)
				if (v[k]) {
					if (be == -1 || a[k].h > a[be].h) be = k;
				}
			if (be != -1) b[i][be] += (j->t-la);
			la = j->t;
			if (j->c >= 0) v[j->c] = 1;
			else v[-j->c-1] = 0;
		}
	}
	
	double T = 0;
	
	while (true) {
		for (int i = 0; i < n; i ++) sp[i] = 0;
		sp[0] = 100;
		for (int i = 0; i < n; i ++)
			if (full[i]) {
				for (int j = i+1; j < n; j ++)
					sp[j] += sp[i] * b[i][j];
			}
		int ne = -1;
		double nt = 0;
		for (int i = 0; i < n; i ++) 
			if (!full[i] && sp[i] > eps) {
				double ti = (a[i].v-cv[i])/sp[i];
				if (ti < nt || ne == -1) {
					ne = i;
					nt = ti;
				}
			}
		if (ne == -1) break;
		for (int i = 0; i < n; i ++)
			if (!full[i]) cv[i] += sp[i] * nt;
		full[ne] = true;
		T += nt;
		// printf ("%d %.2lf\n", ne, nt);
	}
	bool F = true;
	for (int i = 0; i < n; i ++)
		if (!full[i]) F = false; 
	if (F) printf ("%.2lf\n", T);
	else puts ("Invalid");
	return 0;
}
