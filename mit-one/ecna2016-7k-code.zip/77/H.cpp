#include <bits/stdc++.h>
using namespace std;

typedef pair<int, int> PII;
typedef long long ll;

#define fi first
#define se second
#define mp make_pair
#define pb push_back

#define N 110
string a[N];
int n, m;
int v[N][N];

int f[N*N], g[N*N];

int fa(int x) {
	if (x == f[x]) return x;
	else return f[x] = fa(f[x]);
}

bool chk(int w, int x, int y) {
	bool F = 0;
	for (int j = 0; j < y; j ++)
		if (v[x][j] & w) F = !F;
	return F;
}

bool v1[N][N];

void bfs1() {
	int w = 1;
	queue<PII> q;
	for (int i = 0; i < n; i ++) {
		if (~v[i][0]&w) {v1[i][0] = 1; q.push(mp(i, 0));}
		if (~v[i][m-1]&w) {v1[i][m-1] = 1; q.push(mp(i, m-1));}
	}
	for (int i = 0; i < m; i ++) {
		if (~v[0][i]&w) {v1[0][i] = 1; q.push(mp(0, i));}
		if (~v[n-1][i]&w) {v1[n-1][i] = 1; q.push(mp(n-1, i));}
	}
	while (!q.empty()) {
		PII _x = q.front();
		q.pop();
		int x = _x.fi, y = _x.se;
		if (x > 0 && (~v[x-1][y]&w) && !v1[x-1][y]) {v1[x-1][y] = 1; q.push(mp(x-1, y));}
		if (x < n-1 && (~v[x+1][y]&w) && !v1[x+1][y]) {v1[x+1][y] = 1; q.push(mp(x+1, y));}
		if (y > 0 && (~v[x][y-1]&w) && !v1[x][y-1]) {v1[x][y-1] = 1; q.push(mp(x, y-1));}
		if (y < m-1 && (~v[x][y+1]&w) && !v1[x][y+1]) {v1[x][y+1] = 1; q.push(mp(x, y+1));}
	}
}

bool v2[N][N];

void bfs2() {
	int w = 2;
	queue<PII> q;
	for (int i = 0; i < n; i ++) {
		if (~v[i][0]&w) {v2[i][0] = 1; q.push(mp(i, 0));}
		if (~v[i][m-1]&w) {v2[i][m-1] = 1; q.push(mp(i, m-1));}
	}
	for (int i = 0; i < m; i ++) {
		if (~v[0][i]&w) {v2[0][i] = 1; q.push(mp(0, i));}
		if (~v[n-1][i]&w) {v2[n-1][i] = 1; q.push(mp(n-1, i));}
	}
	while (!q.empty()) {
		PII _x = q.front();
		q.pop();
		int x = _x.fi, y = _x.se;
		if (x > 0 && (~v[x-1][y]&w) && !v2[x-1][y]) {v2[x-1][y] = 1; q.push(mp(x-1, y));}
		if (x < n-1 && (~v[x+1][y]&w) && !v2[x+1][y]) {v2[x+1][y] = 1; q.push(mp(x+1, y));}
		if (y > 0 && (~v[x][y-1]&w) && !v2[x][y-1]) {v2[x][y-1] = 1; q.push(mp(x, y-1));}
		if (y < m-1 && (~v[x][y+1]&w) && !v2[x][y+1]) {v2[x][y+1] = 1; q.push(mp(x, y+1));}
	}
}

int main() {
	cin >> n >> m;
	for (int i = 0; i < n; i ++)
		cin >> a[i];
	for (int i = 1; i < n-1; i ++)
		for (int j = 1; j < m-1; j ++)
			if (a[i][j] != '.' && a[i-1][j] != '.' && a[i+1][j] != '.' && a[i][j-1] != '.' && a[i][j+1] != '.') {
				v[i][j] = 3;
			}
	for (int i = 0; i < n*m; i ++) f[i] = i;
	for (int i = 0; i < n; i ++)
		for (int j = 0; j < m; j ++) {
			if (i > 0 && a[i][j] != '.' && a[i-1][j] != '.' && !v[i][j] && !v[i-1][j]) f[fa(i*m+j)] = fa((i-1)*m+j);
			if (i < n-1 && a[i][j] != '.' && a[i+1][j] != '.' && !v[i][j] && !v[i+1][j]) f[fa(i*m+j)] = fa((i+1)*m+j);
			if (j > 0 && a[i][j] != '.' && a[i][j-1] != '.' && !v[i][j] && !v[i][j-1]) f[fa(i*m+j)] = fa(i*m+j-1);
			if (j < m-1 && a[i][j] != '.' && a[i][j+1] != '.' && !v[i][j] && !v[i][j+1]) f[fa(i*m+j)] = fa(i*m+j+1);
			if (v[i][j]) {
				f[fa((i-1)*m+j)] = fa((i+1)*m+j);
				f[fa(i*m+j-1)] = fa(i*m+j+1);
			}
		}
	for (int i = 0; i < n; i ++) 
		for (int j = 0; j < m; j ++) {
			if (a[i][j] == 'A') g[fa(i*m+j)] = 1;
			if (a[i][j] == 'B') g[fa(i*m+j)] = 2;
		}
	
	for (int i = 0; i < n; i ++)
		for (int j = 0; j < m; j ++) {
			if (g[fa(i*m+j)] == 1) v[i][j] |= 1;
			if (g[fa(i*m+j)] == 2) v[i][j] |= 2;
		}
	
	bfs1();
	bfs2();
	
	int SA = 0, SB = 0, SC = 0;
	for (int i = 0; i < n; i ++)
		for (int j = 0; j < m; j ++)
			if (a[i][j] == '.') {
				bool FA = !v1[i][j];
				bool FB = !v2[i][j];
				if (FA && FB) SC++; else
				if (FA) SA++; else
				if (FB) SB++;
			}
	
	printf ("%d %d %d\n", SA, SB, SC);
	return 0;
}
