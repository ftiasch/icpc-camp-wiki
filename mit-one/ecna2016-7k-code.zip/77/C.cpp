#include <bits/stdc++.h>
using namespace std;

typedef pair<int, int> PII;
typedef long long ll;

#define fi first
#define se second
#define mp make_pair
#define pb push_back

string a;
string b;
string c;

int main() {
	cin >> a >> b;
	int n = (int) a.length();
	for (int i = 0; i < n; i ++) {
		int u = (a[i]-'A') - (b[i]-'A');
		if (u < 0) u += 26;
		char w = 'A' + u;
		b += w;
		c += w;
	}
	cout << c << endl;
	return 0;
}
