#include <bits/stdc++.h>
using namespace std;

#define pct __builtin_popcount
#define N 16
int n;
int a[N][26];
int al[N];
int f[1<<N];
int g[1<<N];
int b[26];

int main() {
	cin >> n;
	for (int i = 0; i < n; i ++) {
		string s;
		cin >> s;
		for (int j = 0; j < (int) s.length(); j ++)
			a[i][s[j]-'a']++;
		al[i] = (int) s.length();
	}
	for (int i = 0; i < (1<<n); i++) {
		for (int j = 0; j < 26; j ++) b[j] = 1e8;
		for (int j = 0; j < n; j ++) 
			if ((i>>j)&1) {
				for (int k = 0; k < 26; k ++) {
					b[k] = min(b[k], a[j][k]);
				}
			}
		for (int j = 0; j < 26; j ++) g[i] += b[j];
	}
	for (int i = 1; i < (1<<n); i++) {
		f[i] = 1e8;
		if (pct(i) == 1) {
			int l = __builtin_ctz(i);
			f[i] = al[l]+1;
			continue;
		}
		for (int j = (i-1)&i; j; j = (j - 1) & i) {
			f[i] = min(f[i], f[j] + f[i^j] - (g[i]+1));
		}
	}
	printf ("%d\n", f[(1<<n)-1]);
	return 0;
}

