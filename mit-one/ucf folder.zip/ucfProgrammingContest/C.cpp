#include <bits/stdc++.h>
using namespace std;

int t, n, m;
int pr[1100000], phi[1100000], mi[1100000], a[1100000];

int Pow(int x, int y, int p) {
	int ans = 1;
	for (int i = 1; i <= y; i *= 2, x = 1LL * x * x % p)
		if (i & y)
			ans = 1LL * ans * x% p;
	return ans;
}

int calc(int k, int m) {
	if (k == n)
		return a[n] % m;
	if (m == 1)
		return 0;
	int y = calc(k + 1, phi[m]);
	if (mi[k + 1] >= phi[m])
		y += phi[m];
	return Pow(a[k], y, m);
}

int main() {	
	for (int i = 2; i <= 1000000; i++)
		if (!pr[i])
			for (int j = i; j <= 1000000; j += i)
				pr[j] = i;
	phi[1] = 1;
	for (int i = 2; i <= 1000000; i++) {
		int x = i;
		while (x % pr[i] == 0)
			x /= pr[i];
		phi[i] = phi[x] * (pr[i] - 1) * (i / x / pr[i]);
	}
	scanf("%d%d", &t, &m);
	while (t--) {
		scanf("%d", &n);
		for (int i = 1; i <= n; i++)
			scanf("%d", &a[i]);
		mi[n + 1] = 1;
		for (int i = n; i; i--) {
			if (a[i] == 1)
				mi[i] = 1;
			else {
				mi[i] = 1;
				for (int j = 1; j <= min(20, mi[i + 1]); j++)
					mi[i] = min((long long) m, 1LL * mi[i] * a[i]);
			}
		}
		printf("%d\n", calc(1, m));
	}
	return 0;
}

