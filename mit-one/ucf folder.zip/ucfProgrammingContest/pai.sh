./J_data > J.in
./J < J.in > J.out
./J_bf < J.in > J.ans
diff J.out J.ans
