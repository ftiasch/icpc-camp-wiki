#include <bits/stdc++.h>
using namespace std;

#define N 100010
int n;
string a[10];
bool f[10][N];
bool g[10][N];
int s[N], t[N], l;

int main() {
	cin >> n;
	for (int i = 0; i < 10; i ++) cin >> a[i];
	for (int i = 0; i < 10; i ++) {
		f[i][n-1] = (a[i][n-1] == '.');
	}
	for (int j = n-2; j >= 0; j--) {
		for (int i = 0; i < 10; i ++) {
			if (a[i][j] == 'X') continue;
			if (f[max(0, i-1)][j+1]) {f[i][j] = true; g[i][j] = true;}
			if (f[min(9, i+1)][j+1]) {f[i][j] = true; g[i][j] = false;}
		}
	}
	bool la = false;
	int i = 9;
	for (int j = 0; j < n-1; j++) {
		if (g[i][j]) {
			if (la) {
				t[l-1] ++;
			} else {
				s[l] = j;
				t[l] = 1;
				l++;
			}
			i = max(0, i-1);
			la = true;
		} else {
			i = min(9, i+1);
			la = false;
		}
	}
	printf ("%d\n", l);
	for (int i = 0; i < l; i ++) printf ("%d %d\n", s[i], t[i]);
	return 0;
}

