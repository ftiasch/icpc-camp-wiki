#include <bits/stdc++.h>
using namespace std;

#define N 1100000

int n;
int x, y;
int ansx, ansy;
vector <int> ve[N];
int up[N], down[N], i[N], ma[N], ma2[N], v[N], f[N];
int n1[N];
bool used[N];

void Upd(int x, int y) {
	if (1LL * x * ansy < 1LL * y * ansx)
		ansx = x, ansy = y;
}

void dfs(int x) {
	if (v[x] == 1)
		down[x] = 1;
	else
		down[x] = 0;
	ma[x] = 0;
	for (i[x] = 0; i[x] < (int) ve[x].size(); i[x]++)
	if (ve[x][i[x]] != f[x]) {
		if (v[x] == 1)
			down[x] = max(down[x], down[ve[x][i[x]]] + 1);
		Upd(v[x], 1 + ma[x] + down[ve[x][i[x]]]);
		ma[x] = max(ma[x], down[ve[x][i[x]]]);
	}
}

void dfs2(int x) {
	if (v[x] != 1)
		up[x] = 0;
	if (v[f[x]] != 1 && v[x] == 1)
		up[x] = 1;
	ma[x] = 0;
	ma2[x] = 0;
	for (i[x] = 0; i[x] < (int) ve[x].size(); i[x]++)
	if (ve[x][i[x]] != f[x]) {
		Upd(v[x], 1 + up[f[x]] + down[ve[x][i[x]]]);
		if (down[ve[x][i[x]]] > ma[x])
			ma2[x] = ma[x], ma[x] = down[ve[x][i[x]]];
		else if (down[ve[x][i[x]]] > ma2[x])
			ma2[x] = down[ve[x][i[x]]];
	}
	if (v[x] == 1) {
		for (i[x] = 0; i[x] < (int) ve[x].size(); i[x]++)
		if (ve[x][i[x]] != f[x]) {
			if (ma[x] == down[ve[x][i[x]]])
				up[ve[x][i[x]]] = 2 + ma2[x];
			else
				up[ve[x][i[x]]] = 2 + ma[x];
			up[ve[x][i[x]]] = max(up[ve[x][i[x]]], 1 + up[x]);
		}
		
	}

}

void bfs() {
	int q, h, i;
	n1[q = h = 1] = 1;
	used[1] = true;
	while (q <= h) {
		int x = n1[q];
		for (int i = 0; i < (int) ve[x].size(); i++)
			if (!used[ve[x][i]]) {
				n1[++h] = ve[x][i];
				f[n1[h]] = x;
				used[n1[h]] = true;
			}
		q += 1;
	}
	for (int i = n; i; i--)
		dfs(n1[i]);
	for (int i = 1; i <= n; i++)
		dfs2(n1[i]);
}

int main() {
	scanf("%d", &n);
	for (int i = 1; i < n; i++) {
		scanf("%d%d", &x, &y);
		ve[x].push_back(y);
		ve[y].push_back(x);
	}
	ansx = 1; ansy = 0;
	for (int i = 1; i <= n; i++) {
		scanf("%d", &v[i]);
		Upd(v[i], 1);
	}
	bfs();
	
	int k = __gcd(ansx, ansy);
	printf("%d/%d\n", ansx / k, ansy / k);
	
	return 0;
}

