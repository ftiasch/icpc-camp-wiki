#include <bits/stdc++.h>
using namespace std;

#define N 1000010
int n, m, k;
int px[N], py[N];
int d[N], ne[N], nd[N], S[N];
bool v[N];

void upd(int x, int y) {
	if (ne[y] != -1) {
		if (ne[x] == -1 || (nd[y] < nd[x])) {
			ne[x] = ne[y];
			nd[x] = nd[y];
		}
	}
}

int main() {
	cin >> n >> m >> k;
	for (int i = 0; i < m; i ++) {
		cin >> px[i] >> py[i];
		px[i] --;
		py[i] --;
		if (px[i] > py[i]) swap(px[i], py[i]);
	}
	memset(d, -1, sizeof d);
	for (int i = k; i < n; i ++) d[i] = m;
	for (int i = m-1; i >= 0; i--) {
		int x = px[i], y = py[i];
		if (d[x] != -1 && d[y] == -1) d[y] = i;
		if (d[x] == -1 && d[y] != -1) d[x] = i;
	}
	for (int i = 0; i < k; i ++) {
		int x = d[i];
		if (x != -1) x++;
		printf ("%d%c", x, i==k-1?'\n': ' ');
	}
	
	for (int i = 0; i < m; i ++) {
		int x = px[i], y = py[i];
		if (x < k && i >= d[x]) v[x] = 1;
		if (y < k && i >= d[y]) v[y] = 1;
		v[x] |= v[y];
		v[y] |= v[x];
	}
	int l = 0;
	for (int i = k; i < n; i ++) if (v[i]) l++;
	printf ("%d", l);
	for (int i = k; i < n; i ++) if (v[i]) printf (" %d", i+1);
	puts("");
	
	memset(ne, -1, sizeof ne);
	memset(nd, -1, sizeof nd);
	memset(S, -1, sizeof S);
	for(int i = k; i < n; i ++) ne[i] = i;
	for (int i = m-1; i >= 0; i--) {
		int x = px[i], y = py[i];
		if (x < k) {
			if (y < k) {
				upd(x, y);
				upd(y, x);
				if (i == d[x]) S[x] = ne[x];
				if (i == d[y]) S[y] = ne[y];
			} else {
				ne[x] = y;
				nd[x] = i;
				if (i == d[x]) S[x] = ne[x];
			}
		}
	}
	for (int i = 0; i < k; i ++) {
		int x = S[i];
		if (x != -1) x++;
		printf ("%d%c", x, i==k-1?'\n': ' ');
	}
	return 0;
}

