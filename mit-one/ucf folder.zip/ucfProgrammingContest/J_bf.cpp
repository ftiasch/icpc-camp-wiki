#include <bits/stdc++.h>
using namespace std;

#define N 1100000

int n;
int x, y;
int ansx, ansy;
vector <int> ve[N];
int up[N], down[N], i[N], ma[N], ma2[N], v[N], f[N];
int n1[N];
bool used[N];

void Upd(int x, int y) {
	if (1LL * x * ansy < 1LL * y * ansx)
		ansx = x, ansy = y;
}

void dfs(int k, int f, long long s1, long long s2) {
	s1 *= v[k];
	if (s1 > 1e9)
		return ;
	s2 ++;
	Upd(s1, s2);
	for (int i = 0; i < (int) ve[k].size(); i++)
	if (ve[k][i] != f)
		dfs(ve[k][i], k, s1, s2);
}

int main() {
	scanf("%d", &n);
	for (int i = 1; i < n; i++) {
		scanf("%d%d", &x, &y);
		ve[x].push_back(y);
		ve[y].push_back(x);
	}
	ansx = 1; ansy = 0;
	for (int i = 1; i <= n; i++) {
		scanf("%d", &v[i]);
	}
	
	for (int i = 1; i <= n; i++)
		dfs(i, 0, 1, 0);
	
	int k = __gcd(ansx, ansy);
	printf("%d/%d\n", ansx / k, ansy / k);
	
	return 0;
}

