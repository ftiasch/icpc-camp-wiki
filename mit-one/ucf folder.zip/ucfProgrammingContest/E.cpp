#include <bits/stdc++.h>
using namespace std;

int n, m, w, h, x[6000], y[6000], r[6000];
struct T {
	int r, e, ind;
} qe[110000];
struct pp {
	int x, y;
} par[5000000];
bool ans[110000][5];

double dist[2100][2100];

int fa[6000];
int len;

bool disC[5][5];

bool cmp(pp a, pp b) {
	return dist[a.x][a.y] < dist[b.x][b.y];
}

bool cmp1(T a, T b) {
	return a.r < b.r;
}

int gf(int x) {
	if (fa[x] != x)
		fa[x] = gf(fa[x]);
	return fa[x];
}

bool Same(int a, int b) {
	return gf(n + a) == gf(n + b);
}

int main() {
	scanf("%d%d", &n, &m);
	scanf("%d%d", &w, &h);
	for (int i = 1; i <= n; i++)
		scanf("%d%d%d", &x[i], &y[i], &r[i]);
	for (int i = 1; i <= n; i++)
		for (int j = 1; j < i; j++) {
			dist[i][j] = sqrt(1LL * (x[i] - x[j]) * (x[i] - x[j]) + 1LL * (y[i] - y[j]) * (y[i] - y[j])) - r[i] - r[j];
			len += 1;
			par[len].x = i;
			par[len].y = j;
		}
	for (int i = 1; i <= n; i++)
		dist[i][n + 1] = x[i] - r[i];
	for (int i = 1; i <= n; i++)
		dist[i][n + 2] = w - x[i] - r[i];
	for (int i = 1; i <= n; i++)
		dist[i][n + 3] = h - y[i] - r[i];
	for (int i = 1; i <= n; i++)
		dist[i][n + 4] = y[i] - r[i];
	for (int i = 1; i <= n; i++)
		for (int j = n + 1; j <= n + 4; j++) {
			len += 1;
			par[len].x = i;
			par[len].y = j;
		}
	sort(par + 1, par + len + 1, cmp);
	for (int i = 1; i <= m; i++) {
		scanf("%d%d", &qe[i].r, &qe[i].e);
		qe[i].ind = i;
	}
	sort(qe + 1, qe + m + 1, cmp1);
	
	for (int i = 1; i <= n + 4; i++)
		fa[i] = i;
	
	int q = 1;
	for (int i = 1; i <= m; i++) {
		while (q <= len && dist[par[q].x][par[q].y] < 2 * qe[i].r) {
			fa[gf(par[q].x)] = gf(par[q].y);
			q++;
		}
		disC[1][2] = Same(1, 4) | Same(4, 2) | Same(3, 4);
		disC[1][3] = Same(1, 4) | Same(2, 3) | Same(3, 4) | Same(1, 2);
		disC[1][4] = Same(1, 4) | Same(1, 3) | Same(1, 2);
		disC[2][3] = Same(2, 4) | Same(2, 3) | Same(1, 2);
		disC[2][4] = Same(2, 4) | Same(1, 3) | Same(3, 4) | Same(1, 2);
		disC[3][4] = Same(2, 3) | Same(1, 3) | Same(3, 4);
		
		for (int i1 = 1; i1 <= 4; i1++) {
			disC[i1][i1] = false;
			for (int j = i1 + 1; j <= 4; j++)
				disC[j][i1] = disC[i1][j];
		}
		
		for (int i1 = 1; i1 <= 4; i1++)
			if (!disC[qe[i].e][i1])
				ans[qe[i].ind][i1] =true;
	}
	for (int i1 = 1; i1 <= m; i1++) {
		for (int j = 1; j <= 4; j++)
			if (ans[i1][j])
				printf("%d", j);
		printf("\n");
	}
}

