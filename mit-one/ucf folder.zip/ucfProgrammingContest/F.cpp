#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
#define P 1000000007
const ll inv2 = (P+1)/2;
const ll inv6 = (P+1)/6;
const ll inv3 = (P+1)/3;
const ll inv4 = (P+1)/4;

struct po {
	ll a[5];
	void clr(){a[0]=a[1]=a[2]=a[3]=a[4]=0;}
	void cln() {
		for (ll i = 0; i < 5; i ++) {
			a[i] %= P;
			a[i] += P;
			a[i] %= P;
		}
	}
	po(){clr();}
	po(ll x){clr();a[0] = x;cln();}
	po(ll y, ll x){clr();a[0]=x;a[1]=y;cln();}
	po(ll z, ll y, ll x){clr();a[0]=x;a[1]=y;a[2]=z;cln();}
};

po operator + (const po&a, const po&b) {
	po c;
	for (ll i = 0; i < 5; i ++) c.a[i] = (a.a[i]+b.a[i])%P;
	return c;
}

po operator - (const po&a, const po&b) {
	po c;
	for (ll i = 0; i < 5; i ++) c.a[i] = (a.a[i]-b.a[i]+P)%P;
	return c;
}

po operator * (const po&a, const po&b) {
	po c;
	for (ll i = 0; i < 5; i ++)
		for (ll j = 0; i + j < 5; j ++)
			c.a[i+j] = ((ll)a.a[i]*b.a[j]+c.a[i+j])%P;
	return c;
}

ll val(const po&a, ll x) {
	x %= P;
	x += P;
	x %= P;
	ll s = 0, c = 1;
	for (ll i = 0; i < 5; i ++) {
		s = ((ll)c*a.a[i]+s)%P;
		c = (ll)c*x%P;
	}
	return s;
}

po sum1(const po&a) {
	po c;
	c = c + po(a.a[0])*po(1,0);
	c = c + po(a.a[1])*po(1,0)*po(1,1)*po(inv2);
	c = c + po(a.a[2])*po(1,0)*po(1,1)*po(2,1)*po(inv6);
	c = c + po(a.a[3])*(po(1,0)*po(1,1)*po(inv2))*(po(1,0)*po(1,1)*po(inv2));
	return c;
}

ll sumv(const po&a, ll le, ll ri) {
	//prllf("%d %d %d %d %d\n", a.a[4], a.a[3], a.a[2], a.a[1], a.a[0]);
	po b = sum1(a);
	//prllf("%d %d %d %d %d\n", b.a[4], b.a[3], b.a[2], b.a[1], b.a[0]);
	//prllf ("%d %d\n", le, ri);
	return (val(b,ri)-val(b,le-1)+P)%P;
}

po sum2(const po&a, const po&b, const po&c) {
	return a*(c-b+po(1))+(c-b+po(1))*(c+b)*po(inv2);
}

ll ff(ll x1, ll y1, ll x2, ll y2, const po&a) {
	x1 = max(x1, 1LL);
	y2 = min(y2, x2);
	y1 = max(y1, -x2+1);
	x1 = max(x1, min(y1, -y2+1));
	if (x1 > x2 || y1 > y2) return 0;
	if (x2 <= 0) return 0;
	if (-y2 >= x2) return 0;
	if (y1 > x2) return 0;
	
	//prllf ("%d %d %d %d\n", x1, y1, x2, y2);
	ll xu1 = max(-y1+1,y2);
	ll xu2 = min(y2,-y1+1);
	
	if (-y1+1 <= x1 && y2 <= x1) return sumv(sum2(a,po(y1),po(y2)), x1, x2);
	if (x2 <= y2 && x2 <= -y1+1) return sumv(sum2(a,po(-1,1),po(1,0)), x1, x2);
	
	if (x1 >= xu2 && x2 <= xu1) {
		po lo = po(y1);
		po hi = po(y2);
		if (-y1+1 <= y2) {
			hi = po(1,0);
		} else {
			lo = po(-1,1);
		}
		return sumv(sum2(a,lo,hi), x1, x2);
	}
	
	if (x2 >= xu1 && x1 <= xu1-1) return (ff(x1,y1,xu1-1,y2,a)+ff(xu1,y1,x2,y2,a))%P;
	
	if (x1 <= xu2 && xu2+1 <= x2) return (ff(x1,y1,xu2,y2,a)+ff(xu2+1,y1,x2,y2,a))%P;
}

void mo(ll&x, ll&y) {
	ll zx = x;
	ll zy = y;
	x = zy;
	y = -zx;
}

int main() {
	//prllf ("%d\n", ff(0,-2,1,1,po(2,1)*po(2,1)-po(7,0)));return 0;
	ll n, q;
	cin >> n >> q;
	while (q--) {
		ll x1, y1, x2, y2;
		cin >> x1 >> y1 >> x2 >> y2;
		ll S = 0;
		po a = po(2,1)*po(2,1)-po(7,0);
		(S += ff(x1,y1,x2,y2,a)) %= P;
		mo(x1,y1);mo(x2,y2);if(x1>x2)swap(x1,x2);if(y1>y2)swap(y1,y2);
		(S += ff(x1,y1,x2,y2,a+po(2,0))) %= P;
		mo(x1,y1);mo(x2,y2);if(x1>x2)swap(x1,x2);if(y1>y2)swap(y1,y2);
		(S += ff(x1,y1,x2,y2,a+po(4,0))) %= P;
		mo(x1,y1);mo(x2,y2);if(x1>x2)swap(x1,x2);if(y1>y2)swap(y1,y2);
		(S += ff(x1,y1,x2,y2,a+po(6,0))) %= P;
		mo(x1,y1);mo(x2,y2);if(x1>x2)swap(x1,x2);if(y1>y2)swap(y1,y2);
		if (x1 <= 0 && 0 <= x2 && y1 <= 0 && 0 <= y2) (S += 1) %= P;
		cout << S << endl;
	}
	return 0;
}

