#include <bits/stdc++.h>
using namespace std;

#define P1 1000000007
#define P2 1000000009
#define B1 37
#define B2 137

int n, x, y, t, k, m;
char S[610000];
struct T {
	int sum, key;
	int sum_z, z, hash1, hash2;
	T *l, *r;
} f[6000001], *f1 = f, *null, *root, *temp, *oldroot;
int pw1[610000], pw2[610000], z[610000], xx[610000];

struct pp{
	T *l, *r;
} *p, *q;

T* newp() {
	return ++f1;	
}

void copy(T *x, T *y) {
	x -> sum = y -> sum;
	x -> key = y -> key;
	x -> sum_z = y -> sum_z;
	x -> z = y -> z;
	x -> hash1 = y -> hash1;
	x -> hash2 = y -> hash2;
	x -> l = y -> l;
	x -> r = y -> r;
}

void update(T *k) {
	k -> sum = k -> l -> sum + k -> r -> sum + 1;
	k -> sum_z = k -> l -> sum_z + k -> r -> sum_z + k -> z;
	k -> hash1 = (1LL * k -> l -> hash1 * pw1[k -> r -> sum + 1] + 1LL * k -> z * pw1[k -> r -> sum] + k -> r -> hash1) % P1;
	k -> hash2 = (1LL * k -> l -> hash2 * pw2[k -> r -> sum + 1] + 1LL * k -> z * pw2[k -> r -> sum] + k -> r -> hash2) % P2;
}

void split(T *&k, int x) {
	if (k == null) {
		p -> l = p -> r = null;
	}else {
		T *n = newp();
		copy(n, k);
		k = n;
		if (k -> l -> sum + 1 <= x) {
			split(k -> r, x - k -> l -> sum - 1);
			k = n;
			k -> r = p -> l;
			p -> l = k;
			update(k);
		}else {
			split(k -> l, x);
			k -> l = p -> r;
			p -> r = k;
			update(k);
		}
	}
}

T *merge(T *&x, T *&y) {
	if (x == null)
		return y;
	else if (y == null)
		return x;
	T *n = newp();
	if (x -> key > y -> key) {
		copy(n, x);
		x = n;
		x -> r = merge(x -> r, y);
		update(x);
		return x;
	}else {
		copy(n, y);
		y = n;
		y -> l = merge(x, y -> l);
		update(y);
		return y;
	}
}

void dfs_make(T *&k, int q, int h) {
	k = newp();
	int ma = q;
	for (int i = q; i <= h; i++)
	if (xx[i] > xx[ma])
		ma = i;
	if (q < ma) {
		dfs_make(k -> l, q, ma - 1);
	}else k -> l = null;
	
	k -> sum = 1;
	k -> z = z[ma];
	k -> key = x[ma];
	
	if (ma < h)
		dfs_make(k -> r, ma + 1, h);
	else
		k -> r = null;
	

	update(k);
}

void make_it(T *&k, int n) {
	for (int i = 1; i <= n; i++)
		xx[i] = rand();
	dfs_make(k, 1, n);
}

void modify(int x, int t) {
	oldroot = root;
	split(root, k - 1);
	temp = p -> l;
	q = p;
	split(q -> r, 1);
	p -> l -> z = (p -> l -> z + t) % 26;
	update(p -> l);
	root = merge(temp, merge(p -> l, p -> r));
}

pair <int, long long> getInfo(int x, int l) {
	oldroot = root;
	split(root, k - 1);
	temp = p -> l;
	q = p;
	split(q -> r, l - 1);
	root = oldroot;
	
	return make_pair(temp -> sum_z, 1LL * p -> l * hash1 * 1000000010 + 1LL * p -> l * hash2);
}

int main() {
	null = new T;
	null -> l = null -> r = null;
	null -> sum = null -> z = null -> sum_z = null -> hash1 = null -> hash2 = 0;
	scanf("%s", S + 1);
	n = strlen(S + 1);
	pw1[0] = pw2[0] = 1;
	for (int i = 1; i <= n; i++) {
		pw1[i] = 1LL * pw1[i - 1] * B1 % P1;
		pw2[i] = 1LL * pw2[i - 1] * B2 % P2;
	}
	S[0] = 'a';
	for (int i = 1; i <= n; i++)
		z[i] = (S[i] - S[i - 1] + 26) % 26;
	make_it(root, n);
	scanf("%d", &m);
	
	while (m--) {
		scanf("%d", &t);
		if (t == 1) {
			scanf("%d%d%d", &x, &y, &k);
			if (getInfo(x, y - x + 1) == getInfo(k, y - x + 1))
				printf("Y\n");
			else
				printf("N\n");
		}else if (t == 2) {
			scanf("%d%d%d", &x, &y, &k);
			
			int l = y - x + 1;
			oldroot = root;
			split(root, k - 1);
			int zzk = p -> l -> sum_z;
			q = p;
			split(q -> r, l);
			temp = p -> l;
			root = oldroot;
			
			split(root, x - 1);
			int zzx = p -> l -> sum_z;
			root = p -> l;
			q = p;
			split(q -> r, l);
			root = merge(root, merge(temp, p -> r));
			
			modify(x, (zzk - zzx + 26) % 26);
		}else {
			scanf("%d%d", &x, &y);
			modify(x, 1);
			if (y <= n)
				modify(y + 1, 25);
		}
	}
	
	return 0;
}

