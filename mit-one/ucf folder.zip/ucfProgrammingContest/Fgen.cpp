#include <bits/stdc++.h>
using namespace std;

int main() {
	int u = 1e5;
	int q = 100;
	printf ("%d %d\n", u, q);
	while (q--) {
		int x1 = rand()%(u*2+1)-u;
		int x2 = rand()%(u*2+1)-u;
		int y1 = rand()%(u*2+1)-u;
		int y2 = rand()%(u*2+1)-u;
		if (x1 > x2) swap(x1, x2);
		if (y1 > y2) swap(y1, y2);
		printf ("%d %d %d %d\n", x1, y1, x2, y2);
	}
	return 0;
}

