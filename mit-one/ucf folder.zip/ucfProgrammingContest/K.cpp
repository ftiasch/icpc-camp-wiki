#include <bits/stdc++.h>
using namespace std;

#define pb push_back
#define N 500100
int n;
int a[N], bv[N], av[N];
int u[N];

int ne[N]; bool v[N];

int fa(int x) {
	if (ne[x] == x) return x;
	else return ne[x] = fa(ne[x]);
}
int ff() {
	for (int i = 0; i < n; i ++) ne[i] = i;
	for (int i = 0; i < n-1; i ++) {
		int x = fa(a[i]);
		ne[x] = ne[(x+1)%n];
	}
	return fa(a[n-1]);
}

void gg(int*a, int k) {
	memcpy(u, a, sizeof u);
	for (int i = 0; i < k; i ++) 
		a[n-k+i] = u[i];
	for (int i = k; i < n; i ++)
		a[i-k] = u[i];
}

vector<int> A[N];
set<int> B;

int main() {
	cin >> n;
	for (int i = 0; i < n; i ++) {
		cin >> a[i]; a[i] --;
	}
	for (int i = 0; i < n; i ++) cin >> bv[i];
	for (int i = 0; i < n; i ++) cin >> av[i];
	
	int k = ff()+1;
	gg(bv, k);
	for (int i = 0; i < n; i ++) a[i] = (a[i]+n-k)%n;
	
	for (int i = 0; i < n; i ++) A[a[i]].pb(av[i]);
	int S = 0;
	for (int i = 0; i < n; i ++) {
		for (int j = 0; j < (int) A[i].size(); j ++)
			B.insert(A[i][j]);
		set<int>::iterator c = B.lower_bound(bv[i]);
		if (c == B.end()) {
			B.erase(B.begin());
		} else {
			S ++;
			B.erase(c);
		}
	}
	cout << S << endl;
	return 0;
}

