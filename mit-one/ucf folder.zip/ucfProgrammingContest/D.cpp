#include <bits/stdc++.h>
using namespace std;

int n, l, ans, d[11000], n1[11000];
vector <int> ve[11000];

int bfs(int k) {
	
	int q, h, i;
	for (i = 1; i <= n; i++)
		d[i] = 0;
	d[k] = 1;
	n1[q = h = 1] = k;
	while (q <= h) {
		for (int i = 0; i < (int) ve[n1[q]].size(); i++)
			if (!d[ve[n1[q]][i]]) {
				h += 1;
				n1[h] = ve[n1[q]][i];
				d[ve[n1[q]][i]] = d[n1[q]] + 1;
			}
		q += 1;
	}
	if (h != n)
		return n * n;
	int sum = 0;
	for (int i = 1; i <= n; i++)
		sum += d[i];
	return sum;
}

int main() {
	scanf("%d", &n);
	for (int i = 1; i <= n; i++) {
		scanf("%d", &l);
		while (l--) {
			int x;
			scanf("%d", &x);
			ve[x].push_back(i);
		}
	}
	ans = n * n;
	for (int i = 1; i <= n; i++)
		ans = min(ans, bfs(i));
	printf("%d\n", ans);
}

