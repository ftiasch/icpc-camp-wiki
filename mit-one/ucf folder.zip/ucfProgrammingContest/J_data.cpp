#include <bits/stdc++.h>
using namespace std;

int main() {
	int n = 1000;
	srand(time(NULL));
	printf("%d\n", n);
	for (int i = 2; i <= n; i++)
	if (rand() % 100 != 0)
		printf("%d %d\n", i, rand() % (i - 1) + 1);
	else
		printf("%d %d\n", i, i - 1);
	for (int i= 1; i <= n; i++)
	if (rand() % 20 != 0)
		printf("1\n");
	else
		printf("%d\n", rand() % 4 + 1);
	
}

