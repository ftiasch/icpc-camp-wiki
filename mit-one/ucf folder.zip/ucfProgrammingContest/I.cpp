#include <bits/stdc++.h>
using namespace std;

#define N 110
#define C 26
int n; string a[N]; int p[N];

bool v[C][C]; int id[C];
int q[C];
int iq[C];

int main() {
	cin >> n;
	for (int i = 0; i < n; i ++) cin >> a[i];
	for (int i = 0; i < n; i ++) {
		cin >> p[i];
		p[i] --;
	}
	for (int i = 0; i < n-1; i ++) {
		int l = 0;
		string s = a[p[i]];
		string t = a[p[i+1]];
		int sl = (int) s.length();
		int tl = (int) t.length();
		while (l < sl && l < tl && s[l] == t[l]) l++;
		if (l == tl) {puts ("NO"); return 0;}
		if (l == sl) continue;
		v[s[l]-'a'][t[l]-'a']++;
	}
	for (int i = 0; i < C; i ++)
		for (int j = 0; j < C; j ++)
			if (v[i][j]) id[j]++;
	int l = 0, r = 0;
	for (int i = 0; i < C; i ++)
		if (id[i] == 0) q[r++] = i;
	while (l < r) {
		int c = q[l++];
		for (int i = 0; i < C; i ++)
			if (v[c][i]) {
				id[i]--;
				if (id[i] == 0) q[r++] = i;
			}
	}
	if (r != C) {puts ("NO"); return 0;}
	puts ("YES");
	for (int i = 0; i < C; i ++) iq[q[i]] = i;
	for (int i = 0; i < C; i ++) putchar((char)('a'+iq[i]));
	puts("");
	return 0;
}

