#include <bits/stdc++.h>
using namespace std;

int main() {
	int c, n;
	cin >> c >> n;
	c *= (n+1);
	while (n--) {
		int x; cin >> x;
		c -= x;
	}
	cout << c << endl;
	return 0;
}

